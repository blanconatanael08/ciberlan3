import { Hono } from "hono";
import { cors } from "hono/cors";
import { zValidator } from "@hono/zod-validator";
import { CreateUserSchema, UpdateUserSchema, AdminPasswordSchema, UpdateRankBenefitSchema, CreatePlayerStarSchema, UpdatePlayerStarSchema } from "@/shared/types";

const app = new Hono<{ Bindings: Env }>();

app.use("/*", cors());

// Get all users ordered by XP
app.get("/api/users", async (c) => {
  const db = c.env.DB;
  const users = await db.prepare(
    "SELECT * FROM users ORDER BY xp DESC"
  ).all();
  
  // Convert is_special from 0/1 to boolean
  const formattedUsers = users.results.map((user: any) => ({
    ...user,
    is_special: user.is_special === 1
  }));
  
  return c.json(formattedUsers);
});

// Verify admin password
app.post("/api/admin/verify", zValidator("json", AdminPasswordSchema), async (c) => {
  const { password } = c.req.valid("json");
  const correctPassword = c.env.ADMIN_PASSWORD;
  
  if (password === correctPassword) {
    return c.json({ success: true });
  }
  
  return c.json({ success: false, error: "Contraseña incorrecta" }, 401);
});

// Create user (admin only)
app.post("/api/users", zValidator("json", CreateUserSchema), async (c) => {
  const adminPassword = c.req.header("X-Admin-Password");
  
  if (adminPassword !== c.env.ADMIN_PASSWORD) {
    return c.json({ error: "No autorizado" }, 401);
  }
  
  const data = c.req.valid("json");
  const db = c.env.DB;
  
  const result = await db.prepare(
    "INSERT INTO users (name, rank, xp, is_special, created_at, updated_at) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)"
  ).bind(data.name, data.rank, data.xp, data.is_special ? 1 : 0).run();
  
  const newUser = await db.prepare(
    "SELECT * FROM users WHERE id = ?"
  ).bind(result.meta.last_row_id).first();
  
  // Convert is_special from 0/1 to boolean
  const formattedUser = newUser ? {
    ...newUser,
    is_special: (newUser as any).is_special === 1
  } : null;
  
  return c.json(formattedUser, 201);
});

// Update user (admin only)
app.put("/api/users/:id", zValidator("json", UpdateUserSchema), async (c) => {
  const adminPassword = c.req.header("X-Admin-Password");
  
  if (adminPassword !== c.env.ADMIN_PASSWORD) {
    return c.json({ error: "No autorizado" }, 401);
  }
  
  const id = c.req.param("id");
  const data = c.req.valid("json");
  const db = c.env.DB;
  
  const updates: string[] = [];
  const values: any[] = [];
  
  if (data.name !== undefined) {
    updates.push("name = ?");
    values.push(data.name);
  }
  if (data.rank !== undefined) {
    updates.push("rank = ?");
    values.push(data.rank);
  }
  if (data.xp !== undefined) {
    updates.push("xp = ?");
    values.push(data.xp);
  }
  if (data.is_special !== undefined) {
    updates.push("is_special = ?");
    values.push(data.is_special ? 1 : 0);
  }
  
  if (updates.length === 0) {
    return c.json({ error: "No hay datos para actualizar" }, 400);
  }
  
  updates.push("updated_at = CURRENT_TIMESTAMP");
  values.push(id);
  
  await db.prepare(
    `UPDATE users SET ${updates.join(", ")} WHERE id = ?`
  ).bind(...values).run();
  
  const updatedUser = await db.prepare(
    "SELECT * FROM users WHERE id = ?"
  ).bind(id).first();
  
  // Convert is_special from 0/1 to boolean
  const formattedUser = updatedUser ? {
    ...updatedUser,
    is_special: (updatedUser as any).is_special === 1
  } : null;
  
  return c.json(formattedUser);
});

// Delete user (admin only)
app.delete("/api/users/:id", async (c) => {
  const adminPassword = c.req.header("X-Admin-Password");
  
  if (adminPassword !== c.env.ADMIN_PASSWORD) {
    return c.json({ error: "No autorizado" }, 401);
  }
  
  const id = c.req.param("id");
  const db = c.env.DB;
  
  await db.prepare("DELETE FROM users WHERE id = ?").bind(id).run();
  
  return c.json({ success: true });
});

// Get all rank benefits
app.get("/api/rank-benefits", async (c) => {
  const db = c.env.DB;
  const benefits = await db.prepare(
    "SELECT * FROM rank_benefits ORDER BY CASE rank WHEN 'Principiante' THEN 1 WHEN 'Gamer' THEN 2 WHEN 'Pro' THEN 3 WHEN 'Ciber' THEN 4 END"
  ).all();
  
  return c.json(benefits.results);
});

// Update rank benefit (admin only)
app.put("/api/rank-benefits/:rank", zValidator("json", UpdateRankBenefitSchema), async (c) => {
  const adminPassword = c.req.header("X-Admin-Password");
  
  if (adminPassword !== c.env.ADMIN_PASSWORD) {
    return c.json({ error: "No autorizado" }, 401);
  }
  
  const rank = c.req.param("rank");
  const data = c.req.valid("json");
  const db = c.env.DB;
  
  await db.prepare(
    "UPDATE rank_benefits SET benefit = ?, updated_at = CURRENT_TIMESTAMP WHERE rank = ?"
  ).bind(data.benefit, rank).run();
  
  const updatedBenefit = await db.prepare(
    "SELECT * FROM rank_benefits WHERE rank = ?"
  ).bind(rank).first();
  
  return c.json(updatedBenefit);
});

// Track page visit
app.post("/api/visits/track", async (c) => {
  const db = c.env.DB;
  
  await db.prepare(
    "INSERT INTO page_visits (visited_at) VALUES (CURRENT_TIMESTAMP)"
  ).run();
  
  return c.json({ success: true });
});

// Get visit statistics (admin only)
app.get("/api/visits/stats", async (c) => {
  const adminPassword = c.req.header("X-Admin-Password");
  
  if (adminPassword !== c.env.ADMIN_PASSWORD) {
    return c.json({ error: "No autorizado" }, 401);
  }
  
  const db = c.env.DB;
  
  // Total visits
  const totalResult = await db.prepare(
    "SELECT COUNT(*) as total FROM page_visits"
  ).first();
  
  // Visits today
  const todayResult = await db.prepare(
    "SELECT COUNT(*) as total FROM page_visits WHERE DATE(visited_at) = DATE('now')"
  ).first();
  
  // Visits this week
  const weekResult = await db.prepare(
    "SELECT COUNT(*) as total FROM page_visits WHERE visited_at >= DATE('now', '-7 days')"
  ).first();
  
  // Visits this month
  const monthResult = await db.prepare(
    "SELECT COUNT(*) as total FROM page_visits WHERE visited_at >= DATE('now', 'start of month')"
  ).first();
  
  return c.json({
    total: totalResult?.total || 0,
    today: todayResult?.total || 0,
    week: weekResult?.total || 0,
    month: monthResult?.total || 0
  });
});

// Get all player stars (admin only)
app.get("/api/player-stars", async (c) => {
  const adminPassword = c.req.header("X-Admin-Password");
  
  if (adminPassword !== c.env.ADMIN_PASSWORD) {
    return c.json({ error: "No autorizado" }, 401);
  }
  
  const db = c.env.DB;
  const stars = await db.prepare(
    "SELECT ps.*, u.name as user_name FROM player_stars ps LEFT JOIN users u ON ps.user_id = u.id ORDER BY ps.season DESC, ps.stars DESC"
  ).all();
  
  return c.json(stars.results);
});

// Get player stars summary for public display
app.get("/api/player-stars/public", async (c) => {
  const db = c.env.DB;
  
  // Get total stars per user across all seasons
  const stars = await db.prepare(
    "SELECT user_id, SUM(stars) as total_stars, COUNT(DISTINCT season) as seasons FROM player_stars GROUP BY user_id"
  ).all();
  
  return c.json(stars.results);
});

// Get player stars by user ID with season details
app.get("/api/player-stars/user/:userId", async (c) => {
  const userId = c.req.param("userId");
  const db = c.env.DB;
  
  const stars = await db.prepare(
    "SELECT * FROM player_stars WHERE user_id = ? ORDER BY season DESC"
  ).bind(userId).all();
  
  return c.json(stars.results);
});

// Create player star (admin only)
app.post("/api/player-stars", zValidator("json", CreatePlayerStarSchema), async (c) => {
  const adminPassword = c.req.header("X-Admin-Password");
  
  if (adminPassword !== c.env.ADMIN_PASSWORD) {
    return c.json({ error: "No autorizado" }, 401);
  }
  
  const data = c.req.valid("json");
  const db = c.env.DB;
  
  const result = await db.prepare(
    "INSERT INTO player_stars (user_id, season, stars, created_at, updated_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)"
  ).bind(data.user_id, data.season, data.stars).run();
  
  const newStar = await db.prepare(
    "SELECT ps.*, u.name as user_name FROM player_stars ps LEFT JOIN users u ON ps.user_id = u.id WHERE ps.id = ?"
  ).bind(result.meta.last_row_id).first();
  
  return c.json(newStar, 201);
});

// Update player star (admin only)
app.put("/api/player-stars/:id", zValidator("json", UpdatePlayerStarSchema), async (c) => {
  const adminPassword = c.req.header("X-Admin-Password");
  
  if (adminPassword !== c.env.ADMIN_PASSWORD) {
    return c.json({ error: "No autorizado" }, 401);
  }
  
  const id = c.req.param("id");
  const data = c.req.valid("json");
  const db = c.env.DB;
  
  const updates: string[] = [];
  const values: any[] = [];
  
  if (data.season !== undefined) {
    updates.push("season = ?");
    values.push(data.season);
  }
  if (data.stars !== undefined) {
    updates.push("stars = ?");
    values.push(data.stars);
  }
  
  if (updates.length === 0) {
    return c.json({ error: "No hay datos para actualizar" }, 400);
  }
  
  updates.push("updated_at = CURRENT_TIMESTAMP");
  values.push(id);
  
  await db.prepare(
    `UPDATE player_stars SET ${updates.join(", ")} WHERE id = ?`
  ).bind(...values).run();
  
  const updatedStar = await db.prepare(
    "SELECT ps.*, u.name as user_name FROM player_stars ps LEFT JOIN users u ON ps.user_id = u.id WHERE ps.id = ?"
  ).bind(id).first();
  
  return c.json(updatedStar);
});

// Delete player star (admin only)
app.delete("/api/player-stars/:id", async (c) => {
  const adminPassword = c.req.header("X-Admin-Password");
  
  if (adminPassword !== c.env.ADMIN_PASSWORD) {
    return c.json({ error: "No autorizado" }, 401);
  }
  
  const id = c.req.param("id");
  const db = c.env.DB;
  
  await db.prepare("DELETE FROM player_stars WHERE id = ?").bind(id).run();
  
  return c.json({ success: true });
});

export default app;
