import { BrowserRouter as Router, Routes, Route } from "react-router";
import RankingPage from "@/react-app/pages/RankingPage";
import AdminPage from "@/react-app/pages/AdminPage";

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<RankingPage />} />
        <Route path="/admin" element={<AdminPage />} />
      </Routes>
    </Router>
  );
}
