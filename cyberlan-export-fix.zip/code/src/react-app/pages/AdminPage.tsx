import { useState } from "react";
import { Link } from "react-router";
import { Shield, LogOut, ArrowLeft } from "lucide-react";
import AdminLogin from "@/react-app/components/AdminLogin";
import AdminDashboard from "@/react-app/components/AdminDashboard";

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [adminPassword, setAdminPassword] = useState("");

  const handleLogin = (password: string) => {
    setAdminPassword(password);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setAdminPassword("");
  };

  if (!isAuthenticated) {
    return <AdminLogin onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900">
      <div className="container mx-auto px-4 py-8">
        {/* Back Button */}
        <div className="mb-6">
          <Link
            to="/"
            className="inline-flex items-center gap-2 px-4 py-2 bg-gray-800/80 hover:bg-gray-700/80 backdrop-blur-sm border border-gray-600/50 rounded-lg text-gray-300 hover:text-white transition-all duration-200"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="font-semibold">Volver al Ranking</span>
          </Link>
        </div>

        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <Shield className="w-10 h-10 text-blue-400" />
            <h1 className="text-4xl font-black text-white">Panel Admin</h1>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
          >
            <LogOut className="w-5 h-5" />
            Cerrar Sesión
          </button>
        </div>

        <AdminDashboard adminPassword={adminPassword} />
      </div>
    </div>
  );
}
