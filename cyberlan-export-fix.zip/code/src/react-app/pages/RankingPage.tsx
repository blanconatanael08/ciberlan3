import { useEffect, useState } from "react";
import { Link } from "react-router";
import { Zap, Shield, Crown, Medal, Star, Gift } from "lucide-react";
import { User, RankBenefit, Rank } from "@/shared/types";
import RankBadge from "@/react-app/components/RankBadge";
import XPBar from "@/react-app/components/XPBar";
import PlayerModal from "@/react-app/components/PlayerModal";

interface UserStars {
  user_id: number;
  total_stars: number;
  seasons: number;
}

export default function RankingPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [rankBenefits, setRankBenefits] = useState<RankBenefit[]>([]);
  const [userStars, setUserStars] = useState<Map<number, UserStars>>(new Map());
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  useEffect(() => {
    loadUsers();
    loadRankBenefits();
    loadUserStars();
    trackVisit();
    const interval = setInterval(() => {
      loadUsers();
      loadRankBenefits();
      loadUserStars();
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const trackVisit = async () => {
    try {
      await fetch("/api/visits/track", {
        method: "POST",
      });
    } catch (error) {
      console.error("Error tracking visit:", error);
    }
  };

  const loadUserStars = async () => {
    try {
      const response = await fetch("/api/player-stars/public");
      const data = await response.json();
      const starsMap = new Map<number, UserStars>();
      data.forEach((item: UserStars) => {
        starsMap.set(item.user_id, item);
      });
      setUserStars(starsMap);
    } catch (error) {
      console.error("Error loading user stars:", error);
    }
  };

  const loadUsers = async () => {
    try {
      const response = await fetch("/api/users");
      const data = await response.json();
      setUsers(data);
    } catch (error) {
      console.error("Error loading users:", error);
    } finally {
      setLoading(false);
    }
  };

  const loadRankBenefits = async () => {
    try {
      const response = await fetch("/api/rank-benefits");
      const data = await response.json();
      setRankBenefits(data);
    } catch (error) {
      console.error("Error loading rank benefits:", error);
    }
  };

  const getBenefitForRank = (rank: Rank): string => {
    const benefit = rankBenefits.find(b => b.rank === rank);
    return benefit?.benefit || "Sin beneficios";
  };

  const top3 = users.slice(0, 3);
  const rest = users.slice(3);

  const getRankEmblem = (user: User, size: 'large' | 'small' = 'large') => {
    const isLarge = size === 'large';
    const containerSize = isLarge ? 'w-20 h-20 md:w-28 md:h-28' : 'w-16 h-16 md:w-20 md:h-20';
    const imgSize = isLarge ? 'w-20 h-20 md:w-28 md:h-28' : 'w-16 h-16 md:w-20 md:h-20';
    const blurIntensity = isLarge ? 'blur-lg md:blur-xl' : 'blur-md md:blur-lg';
    const blurIntensity2 = isLarge ? 'blur-md md:blur-lg' : 'blur-sm md:blur-md';
    
    if (user.rank === "Principiante") {
      return (
        <div className={`relative flex items-center justify-center ${containerSize}`}>
          <div className={`absolute inset-0 bg-gradient-to-br from-blue-400/40 via-cyan-400/40 to-blue-600/40 ${blurIntensity} animate-pulse`}></div>
          <div className={`absolute inset-0 bg-gradient-to-br from-blue-300/30 via-cyan-300/30 to-blue-500/30 ${blurIntensity2} animate-pulse`} style={{ animationDelay: '0.5s' }}></div>
          
          <img 
            src="https://019b19c2-64d0-74af-a20b-44f1a341ddaf.mochausercontent.com/Principiantes.png" 
            alt="Principiante" 
            className={`relative z-10 ${imgSize} object-contain ${isLarge ? 'drop-shadow-[0_0_25px_rgba(56,189,248,1)]' : 'drop-shadow-[0_0_15px_rgba(56,189,248,0.8)]'}`}
            style={{ filter: 'brightness(1.3) contrast(1.15)' }}
          />
        </div>
      );
    }
    
    if (user.rank === "Gamer") {
      return (
        <div className={`relative flex items-center justify-center ${containerSize}`}>
          <div className={`absolute inset-0 bg-gradient-to-br from-purple-400/40 via-fuchsia-400/40 to-purple-600/40 ${blurIntensity} animate-pulse`}></div>
          <div className={`absolute inset-0 bg-gradient-to-br from-purple-300/30 via-fuchsia-300/30 to-purple-500/30 ${blurIntensity2} animate-pulse`} style={{ animationDelay: '0.5s' }}></div>
          
          <img 
            src="https://019b19c2-64d0-74af-a20b-44f1a341ddaf.mochausercontent.com/Gamer.png" 
            alt="Gamer" 
            className={`relative z-10 ${imgSize} object-contain ${isLarge ? 'drop-shadow-[0_0_25px_rgba(192,38,211,1)]' : 'drop-shadow-[0_0_15px_rgba(192,38,211,0.8)]'}`}
            style={{ filter: 'brightness(1.3) contrast(1.15)' }}
          />
        </div>
      );
    }
    
    if (user.rank === "Pro") {
      return (
        <div className={`relative flex items-center justify-center ${containerSize}`}>
          {/* Multi-layered glow auras */}
          <div className={`absolute inset-0 bg-gradient-to-br from-red-500/50 via-rose-500/50 to-red-700/50 ${blurIntensity} animate-pulse`}></div>
          <div className={`absolute inset-0 bg-gradient-to-br from-red-400/40 via-rose-400/40 to-red-600/40 ${blurIntensity2} animate-pulse`} style={{ animationDelay: '0.5s' }}></div>
          <div className={`absolute inset-0 bg-gradient-to-br from-orange-400/30 via-red-400/30 to-rose-600/30 blur-lg animate-pulse`} style={{ animationDelay: '1s' }}></div>
          
          {/* Orbital rings */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div 
              className={`absolute ${isLarge ? 'w-48 h-48 border-2' : 'w-32 h-32 border'} border-red-400/30 rounded-full`}
              style={{ animation: 'spin 8s linear infinite' }}
            ></div>
            <div 
              className={`absolute ${isLarge ? 'w-44 h-44 border-2' : 'w-28 h-28 border'} border-rose-400/20 rounded-full`}
              style={{ animation: 'spin 6s linear infinite reverse' }}
            ></div>
          </div>

          {/* Energy pulses */}
          <div 
            className="absolute inset-0 rounded-full bg-gradient-radial from-red-500/40 to-transparent"
            style={{ animation: 'pulse-ring 2s ease-out infinite' }}
          ></div>

          {/* Diagonal light streaks */}
          <div className="absolute inset-0 overflow-hidden">
            <div 
              className={`absolute ${isLarge ? 'w-1 h-32' : 'w-0.5 h-20'} bg-gradient-to-b from-transparent via-white/70 to-transparent`}
              style={{
                animation: 'diagonal-streak 4s ease-in-out infinite',
                left: '20%',
                top: isLarge ? '-20%' : '-15%',
                transform: 'rotate(-45deg)'
              }}
            ></div>
            <div 
              className={`absolute ${isLarge ? 'w-1 h-24' : 'w-0.5 h-16'} bg-gradient-to-b from-transparent via-red-300/60 to-transparent`}
              style={{
                animation: 'diagonal-streak 4s ease-in-out infinite',
                right: '25%',
                bottom: '-15%',
                transform: 'rotate(-45deg)',
                animationDelay: '2s'
              }}
            ></div>
          </div>
          
          <img 
            src="https://019b19c2-64d0-74af-a20b-44f1a341ddaf.mochausercontent.com/Veterano.png" 
            alt="Pro" 
            className={`relative z-10 ${imgSize} object-contain ${isLarge ? 'drop-shadow-[0_0_35px_rgba(239,68,68,1)]' : 'drop-shadow-[0_0_15px_rgba(239,68,68,0.8)]'}`}
            style={{ 
              filter: 'brightness(1.4) contrast(1.2) saturate(1.1)',
              animation: isLarge ? 'float 3s ease-in-out infinite' : undefined
            }}
          />
          
          {/* Enhanced corner shine */}
          <div 
            className={`absolute top-0 right-0 ${isLarge ? 'w-16 h-16' : 'w-10 h-10'} bg-white/90 rounded-full blur-xl`}
            style={{
              animation: 'corner-shine 3s ease-in-out infinite',
              opacity: 0
            }}
          ></div>
          
          {/* Enhanced sparkle particles with trails */}
          <div className={`absolute ${isLarge ? 'w-2 h-2 top-6 left-12' : 'w-1 h-1 top-3 left-6'} bg-white rounded-full`} style={{ animation: 'sparkle-trail 2s ease-in-out infinite', animationDelay: '0s', boxShadow: isLarge ? '0 0 15px 5px rgba(255,255,255,1), 0 0 30px 8px rgba(239,68,68,0.6)' : '0 0 10px 3px rgba(255,255,255,1)' }}></div>
          <div className={`absolute ${isLarge ? 'w-2.5 h-2.5 top-20 right-8' : 'w-1 h-1 top-10 right-4'} bg-red-200 rounded-full`} style={{ animation: 'sparkle-trail 2.5s ease-in-out infinite', animationDelay: '0.3s', boxShadow: isLarge ? '0 0 15px 5px rgba(254,202,202,1), 0 0 30px 8px rgba(239,68,68,0.6)' : '0 0 10px 3px rgba(254,202,202,1)' }}></div>
          <div className={`absolute ${isLarge ? 'w-2 h-2 bottom-12 left-10' : 'w-1 h-1 bottom-6 left-5'} bg-rose-300 rounded-full`} style={{ animation: 'sparkle-trail 2.2s ease-in-out infinite', animationDelay: '0.6s', boxShadow: isLarge ? '0 0 15px 5px rgba(253,164,175,1), 0 0 30px 8px rgba(239,68,68,0.6)' : '0 0 10px 3px rgba(253,164,175,1)' }}></div>
          <div className={`absolute ${isLarge ? 'w-3 h-3 bottom-8 right-12' : 'w-1 h-1 bottom-4 right-6'} bg-white rounded-full`} style={{ animation: 'sparkle-trail 2.8s ease-in-out infinite', animationDelay: '0.9s', boxShadow: isLarge ? '0 0 15px 5px rgba(255,255,255,1), 0 0 30px 8px rgba(239,68,68,0.6)' : '0 0 10px 3px rgba(255,255,255,1)' }}></div>
          <div className={`absolute ${isLarge ? 'w-2 h-2 top-10 right-20' : 'w-1 h-1 top-5 right-10'} bg-red-300 rounded-full`} style={{ animation: 'sparkle-trail 2.3s ease-in-out infinite', animationDelay: '1.2s', boxShadow: isLarge ? '0 0 15px 5px rgba(252,165,165,1), 0 0 30px 8px rgba(239,68,68,0.6)' : '0 0 10px 3px rgba(252,165,165,1)' }}></div>
          <div className={`absolute ${isLarge ? 'w-2 h-2 bottom-20 left-14' : 'w-1 h-1 bottom-10 left-7'} bg-white rounded-full`} style={{ animation: 'sparkle-trail 2.6s ease-in-out infinite', animationDelay: '1.5s', boxShadow: isLarge ? '0 0 15px 5px rgba(255,255,255,1), 0 0 30px 8px rgba(239,68,68,0.6)' : '0 0 10px 3px rgba(255,255,255,1)' }}></div>
          <div className={`absolute ${isLarge ? 'w-1.5 h-1.5 top-14 left-6' : 'w-1 h-1 top-7 left-3'} bg-orange-300 rounded-full`} style={{ animation: 'sparkle-trail 2.4s ease-in-out infinite', animationDelay: '1.8s', boxShadow: '0 0 12px 4px rgba(253,186,116,1)' }}></div>
        </div>
      );
    }
    
    if (user.rank === "Ciber") {
      return (
        <div className={`relative flex items-center justify-center ${containerSize}`}>
          {/* Multi-layered golden glow auras */}
          <div className={`absolute inset-0 bg-gradient-to-br from-yellow-500/50 via-amber-500/50 to-orange-600/50 ${blurIntensity} animate-pulse`}></div>
          <div className={`absolute inset-0 bg-gradient-to-br from-yellow-400/40 via-amber-400/40 to-orange-500/40 ${blurIntensity2} animate-pulse`} style={{ animationDelay: '0.5s' }}></div>
          <div className={`absolute inset-0 bg-gradient-to-br from-amber-300/30 via-yellow-400/30 to-orange-400/30 blur-lg animate-pulse`} style={{ animationDelay: '1s' }}></div>
          
          {/* Golden orbital rings */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div 
              className={`absolute ${isLarge ? 'w-48 h-48 border-2' : 'w-32 h-32 border'} border-yellow-400/40 rounded-full`}
              style={{ animation: 'spin 8s linear infinite' }}
            ></div>
            <div 
              className={`absolute ${isLarge ? 'w-44 h-44 border-2' : 'w-28 h-28 border'} border-amber-400/30 rounded-full`}
              style={{ animation: 'spin 6s linear infinite reverse' }}
            ></div>
            <div 
              className={`absolute ${isLarge ? 'w-40 h-40 border' : 'w-24 h-24 border'} border-orange-400/20 rounded-full`}
              style={{ animation: 'spin 10s linear infinite' }}
            ></div>
          </div>

          {/* Golden energy pulses */}
          <div 
            className="absolute inset-0 rounded-full bg-gradient-radial from-yellow-400/50 to-transparent"
            style={{ animation: 'pulse-ring 2s ease-out infinite' }}
          ></div>
          <div 
            className="absolute inset-0 rounded-full bg-gradient-radial from-amber-500/40 to-transparent"
            style={{ animation: 'pulse-ring 2s ease-out infinite', animationDelay: '1s' }}
          ></div>

          {/* Diagonal golden light streaks */}
          <div className="absolute inset-0 overflow-hidden">
            <div 
              className={`absolute ${isLarge ? 'w-1 h-32' : 'w-0.5 h-20'} bg-gradient-to-b from-transparent via-white/80 to-transparent`}
              style={{
                animation: 'diagonal-streak 4s ease-in-out infinite',
                left: '20%',
                top: isLarge ? '-20%' : '-15%',
                transform: 'rotate(-45deg)'
              }}
            ></div>
            <div 
              className={`absolute ${isLarge ? 'w-1 h-24' : 'w-0.5 h-16'} bg-gradient-to-b from-transparent via-yellow-300/70 to-transparent`}
              style={{
                animation: 'diagonal-streak 4s ease-in-out infinite',
                right: '25%',
                bottom: isLarge ? '-15%' : '-10%',
                transform: 'rotate(-45deg)',
                animationDelay: '2s'
              }}
            ></div>
          </div>
          
          <img 
            src="https://019b19c2-64d0-74af-a20b-44f1a341ddaf.mochausercontent.com/Pro.png" 
            alt="Ciber" 
            className={`relative z-10 ${imgSize} object-contain ${isLarge ? 'drop-shadow-[0_0_40px_rgba(251,191,36,1)]' : 'drop-shadow-[0_0_15px_rgba(251,191,36,0.8)]'}`}
            style={{ 
              filter: 'brightness(1.5) contrast(1.25) saturate(1.2)',
              animation: isLarge ? 'float 3s ease-in-out infinite' : undefined
            }}
          />
          
          {/* Enhanced golden corner shine */}
          <div 
            className={`absolute top-0 right-0 ${isLarge ? 'w-20 h-20' : 'w-12 h-12'} bg-white/95 rounded-full blur-2xl`}
            style={{
              animation: 'corner-shine 3s ease-in-out infinite',
              opacity: 0
            }}
          ></div>
          
          {/* Enhanced golden sparkle particles with divine trails */}
          <div className={`absolute ${isLarge ? 'w-3 h-3 top-6 left-12' : 'w-1.5 h-1.5 top-3 left-6'} bg-white rounded-full`} style={{ animation: 'sparkle-trail 2s ease-in-out infinite', animationDelay: '0s', boxShadow: isLarge ? '0 0 20px 6px rgba(255,255,255,1), 0 0 40px 10px rgba(251,191,36,0.8)' : '0 0 12px 4px rgba(255,255,255,1)' }}></div>
          <div className={`absolute ${isLarge ? 'w-3.5 h-3.5 top-20 right-8' : 'w-1.5 h-1.5 top-10 right-4'} bg-yellow-200 rounded-full`} style={{ animation: 'sparkle-trail 2.5s ease-in-out infinite', animationDelay: '0.3s', boxShadow: isLarge ? '0 0 20px 6px rgba(254,240,138,1), 0 0 40px 10px rgba(251,191,36,0.8)' : '0 0 12px 4px rgba(254,240,138,1)' }}></div>
          <div className={`absolute ${isLarge ? 'w-2.5 h-2.5 bottom-12 left-10' : 'w-1 h-1 bottom-6 left-5'} bg-amber-300 rounded-full`} style={{ animation: 'sparkle-trail 2.2s ease-in-out infinite', animationDelay: '0.6s', boxShadow: isLarge ? '0 0 18px 5px rgba(252,211,77,1), 0 0 35px 9px rgba(251,191,36,0.8)' : '0 0 12px 4px rgba(252,211,77,1)' }}></div>
          <div className={`absolute ${isLarge ? 'w-3.5 h-3.5 bottom-8 right-12' : 'w-1.5 h-1.5 bottom-4 right-6'} bg-white rounded-full`} style={{ animation: 'sparkle-trail 2.8s ease-in-out infinite', animationDelay: '0.9s', boxShadow: isLarge ? '0 0 20px 6px rgba(255,255,255,1), 0 0 40px 10px rgba(251,191,36,0.8)' : '0 0 12px 4px rgba(255,255,255,1)' }}></div>
          <div className={`absolute ${isLarge ? 'w-2.5 h-2.5 top-10 right-20' : 'w-1 h-1 top-5 right-10'} bg-yellow-300 rounded-full`} style={{ animation: 'sparkle-trail 2.3s ease-in-out infinite', animationDelay: '1.2s', boxShadow: isLarge ? '0 0 18px 5px rgba(253,224,71,1), 0 0 35px 9px rgba(251,191,36,0.8)' : '0 0 12px 4px rgba(253,224,71,1)' }}></div>
          <div className={`absolute ${isLarge ? 'w-3 h-3 bottom-20 left-14' : 'w-1.5 h-1.5 bottom-10 left-7'} bg-white rounded-full`} style={{ animation: 'sparkle-trail 2.6s ease-in-out infinite', animationDelay: '1.5s', boxShadow: isLarge ? '0 0 20px 6px rgba(255,255,255,1), 0 0 40px 10px rgba(251,191,36,0.8)' : '0 0 12px 4px rgba(255,255,255,1)' }}></div>
          <div className={`absolute ${isLarge ? 'w-2 h-2 top-14 left-6' : 'w-1 h-1 top-7 left-3'} bg-orange-300 rounded-full`} style={{ animation: 'sparkle-trail 2.4s ease-in-out infinite', animationDelay: '1.8s', boxShadow: '0 0 15px 4px rgba(253,186,116,1)' }}></div>
          <div className={`absolute ${isLarge ? 'w-2.5 h-2.5 bottom-14 right-6' : 'w-1 h-1 bottom-7 right-3'} bg-amber-200 rounded-full`} style={{ animation: 'sparkle-trail 2.7s ease-in-out infinite', animationDelay: '2.1s', boxShadow: '0 0 18px 5px rgba(253,230,138,1)' }}></div>
        </div>
      );
    }
    
    return null;
  };

  const PodiumCard = ({ user, position }: { user: User; position: number }) => {
    const heights = {
      1: "min-h-[16rem] md:h-[20rem]",
      2: "min-h-[14rem] md:h-[16rem]", 
      3: "min-h-[14rem] md:h-[15rem]"
    };

    const medalColors = {
      1: "text-yellow-400",
      2: "text-gray-300",
      3: "text-orange-600"
    };

    const podiumStyles = {
      1: {
        gradient: "from-orange-900/50 via-red-800/60 to-orange-900/50",
        border: "border-orange-500/80",
        glow: "shadow-[0_0_80px_rgba(249,115,22,0.9),0_0_120px_rgba(251,146,60,0.6),inset_0_0_80px_rgba(249,115,22,0.2)]",
        innerGlow: "bg-gradient-to-b from-orange-500/25 via-yellow-600/15 to-red-600/25",
        shine: "bg-gradient-to-br from-yellow-400/25 via-transparent to-transparent"
      },
      2: {
        gradient: "from-slate-700/40 via-gray-600/50 to-slate-700/40",
        border: "border-gray-300/60",
        glow: "shadow-[0_0_40px_rgba(203,213,225,0.6),0_0_70px_rgba(203,213,225,0.4),inset_0_0_40px_rgba(203,213,225,0.1)]",
        innerGlow: "bg-gradient-to-b from-gray-300/15 via-slate-400/8 to-gray-500/15",
        shine: "bg-gradient-to-br from-white/15 via-transparent to-transparent"
      },
      3: {
        gradient: "from-orange-900/40 via-amber-700/50 to-orange-900/40",
        border: "border-orange-400/60",
        glow: "shadow-[0_0_40px_rgba(251,146,60,0.6),0_0_70px_rgba(251,146,60,0.4),inset_0_0_40px_rgba(251,146,60,0.1)]",
        innerGlow: "bg-gradient-to-b from-orange-400/15 via-amber-500/8 to-orange-600/15",
        shine: "bg-gradient-to-br from-white/15 via-transparent to-transparent"
      }
    };

    return (
      <div className={`flex flex-col items-center ${position === 1 ? 'md:order-2' : position === 2 ? 'md:order-1' : 'md:order-3'} relative`}>
        {/* Fire effects for first place */}
        {position === 1 && (
          <>
            {/* Fire glow base */}
            <div className="absolute -inset-16 md:-inset-24 bg-gradient-radial from-orange-600/30 via-yellow-600/15 to-transparent rounded-full blur-3xl pointer-events-none" style={{ animation: 'pulse 2s ease-in-out infinite' }}></div>
            <div className="absolute -inset-12 md:-inset-20 bg-gradient-radial from-yellow-500/25 via-orange-500/15 to-transparent rounded-full blur-2xl pointer-events-none" style={{ animation: 'pulse 2s ease-in-out infinite', animationDelay: '0.5s' }}></div>
            <div className="absolute -inset-8 md:-inset-12 bg-gradient-radial from-orange-400/20 via-red-500/10 to-transparent rounded-full blur-xl pointer-events-none" style={{ animation: 'pulse 2s ease-in-out infinite', animationDelay: '1s' }}></div>
            
            {/* Flame licks - left side */}
            <div className="absolute -left-8 md:-left-12 top-1/4 w-12 md:w-20 h-20 md:h-32 bg-gradient-to-t from-orange-600/0 via-orange-500/60 to-yellow-400/40 blur-lg pointer-events-none" style={{ animation: 'pulse 1.5s ease-in-out infinite', clipPath: 'polygon(50% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)' }}></div>
            <div className="absolute -left-6 md:-left-10 top-1/3 w-10 md:w-16 h-16 md:h-24 bg-gradient-to-t from-red-600/0 via-orange-400/50 to-yellow-300/30 blur-md pointer-events-none" style={{ animation: 'pulse 1.8s ease-in-out infinite', animationDelay: '0.3s', clipPath: 'polygon(50% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)' }}></div>
            
            {/* Flame licks - right side */}
            <div className="absolute -right-8 md:-right-12 top-1/4 w-12 md:w-20 h-20 md:h-32 bg-gradient-to-t from-orange-600/0 via-orange-500/60 to-yellow-400/40 blur-lg pointer-events-none" style={{ animation: 'pulse 1.5s ease-in-out infinite', animationDelay: '0.4s', clipPath: 'polygon(50% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)' }}></div>
            <div className="absolute -right-6 md:-right-10 top-1/3 w-10 md:w-16 h-16 md:h-24 bg-gradient-to-t from-red-600/0 via-orange-400/50 to-yellow-300/30 blur-md pointer-events-none" style={{ animation: 'pulse 1.8s ease-in-out infinite', animationDelay: '0.7s', clipPath: 'polygon(50% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)' }}></div>
            
            {/* Flame licks - top */}
            <div className="absolute top-0 left-1/4 w-12 md:w-16 h-16 md:h-24 bg-gradient-to-t from-orange-600/0 via-orange-500/50 to-yellow-400/30 blur-lg pointer-events-none" style={{ animation: 'pulse 1.6s ease-in-out infinite', animationDelay: '0.2s', clipPath: 'polygon(50% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)' }}></div>
            <div className="absolute top-0 right-1/4 w-12 md:w-16 h-16 md:h-24 bg-gradient-to-t from-orange-600/0 via-orange-500/50 to-yellow-400/30 blur-lg pointer-events-none" style={{ animation: 'pulse 1.6s ease-in-out infinite', animationDelay: '0.6s', clipPath: 'polygon(50% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)' }}></div>
          </>
        )}
        
        {position === 2 && (
          <div className="absolute -inset-12 md:-inset-16 bg-gradient-radial from-gray-400/15 via-gray-300/8 to-transparent rounded-full blur-2xl animate-pulse pointer-events-none"></div>
        )}
        
        {position === 3 && (
          <div className="absolute -inset-12 md:-inset-16 bg-gradient-radial from-orange-500/15 via-orange-400/8 to-transparent rounded-full blur-2xl animate-pulse pointer-events-none"></div>
        )}

        {/* Medal/Crown Icon - Enhanced */}
        <div className="mb-2 md:mb-3 relative z-20">
          {position === 1 && (
            <>
              <Crown className={`w-8 h-8 md:w-12 md:h-12 ${medalColors[position as keyof typeof medalColors]} drop-shadow-[0_0_25px_rgba(250,204,21,1)] animate-pulse`} />
              {/* Crown aura */}
              <div className="absolute inset-0 -m-2 bg-yellow-400/30 rounded-full blur-xl animate-pulse"></div>
              <div className="absolute inset-0 -m-3 bg-yellow-300/20 rounded-full blur-2xl animate-pulse" style={{ animationDelay: '0.5s' }}></div>
            </>
          )}
          {position === 2 && (
            <>
              <Medal className={`w-7 h-7 md:w-10 md:h-10 ${medalColors[position as keyof typeof medalColors]} drop-shadow-[0_0_18px_rgba(209,213,219,0.9)]`} />
              <div className="absolute inset-0 -m-2 bg-gray-300/20 rounded-full blur-lg animate-pulse"></div>
            </>
          )}
          {position === 3 && (
            <>
              <Medal className={`w-7 h-7 md:w-10 md:h-10 ${medalColors[position as keyof typeof medalColors]} drop-shadow-[0_0_18px_rgba(234,88,12,0.9)]`} />
              <div className="absolute inset-0 -m-2 bg-orange-400/20 rounded-full blur-lg animate-pulse"></div>
            </>
          )}
        </div>

        {/* Podium Block - Premium Enhanced */}
        <div 
          onClick={() => setSelectedUser(user)}
          className={`
          relative w-full max-w-[280px] md:w-56 ${heights[position as keyof typeof heights]}
          bg-gradient-to-b ${podiumStyles[position as keyof typeof podiumStyles].gradient}
          border-4 ${podiumStyles[position as keyof typeof podiumStyles].border}
          ${podiumStyles[position as keyof typeof podiumStyles].glow}
          rounded-t-3xl backdrop-blur-xl
          transition-all duration-500 hover:scale-[1.08] hover:-translate-y-2
          flex flex-col items-center justify-start pt-4 md:pt-8 px-4 md:px-6
          overflow-visible cursor-pointer
        `}>
          {/* Premium glass overlay */}
          <div className={`absolute inset-0 rounded-t-3xl ${podiumStyles[position as keyof typeof podiumStyles].innerGlow} -z-10`}></div>
          
          {/* Top shine effect */}
          <div className={`absolute inset-0 rounded-t-3xl ${podiumStyles[position as keyof typeof podiumStyles].shine} -z-10`}></div>
          
          {/* Frosted glass border effect */}
          <div className="absolute inset-0 rounded-t-3xl bg-white/5 backdrop-blur-sm -z-10"></div>
          
          {/* Fire embers rising from bottom */}
          {position === 1 && (
            <>
              <div className="absolute bottom-0 left-1/4 w-2 h-2 bg-orange-500 rounded-full blur-sm" style={{ animation: 'sparkle-trail 3s ease-in-out infinite', animationDelay: '0s', boxShadow: '0 0 10px rgba(249,115,22,0.8)' }}></div>
              <div className="absolute bottom-0 left-1/2 w-1.5 h-1.5 bg-yellow-400 rounded-full blur-sm" style={{ animation: 'sparkle-trail 3.5s ease-in-out infinite', animationDelay: '0.5s', boxShadow: '0 0 8px rgba(250,204,21,0.8)' }}></div>
              <div className="absolute bottom-0 right-1/4 w-2 h-2 bg-orange-600 rounded-full blur-sm" style={{ animation: 'sparkle-trail 3.2s ease-in-out infinite', animationDelay: '1s', boxShadow: '0 0 10px rgba(234,88,12,0.8)' }}></div>
              <div className="absolute bottom-0 left-1/3 w-1 h-1 bg-red-500 rounded-full blur-sm" style={{ animation: 'sparkle-trail 2.8s ease-in-out infinite', animationDelay: '1.5s', boxShadow: '0 0 6px rgba(239,68,68,0.8)' }}></div>
              <div className="absolute bottom-0 right-1/3 w-1.5 h-1.5 bg-yellow-300 rounded-full blur-sm" style={{ animation: 'sparkle-trail 3.3s ease-in-out infinite', animationDelay: '2s', boxShadow: '0 0 8px rgba(253,224,71,0.8)' }}></div>
              <div className="absolute bottom-0 left-2/3 w-1 h-1 bg-orange-400 rounded-full blur-sm" style={{ animation: 'sparkle-trail 2.9s ease-in-out infinite', animationDelay: '0.8s', boxShadow: '0 0 6px rgba(251,146,60,0.8)' }}></div>
              <div className="absolute bottom-0 right-2/3 w-1.5 h-1.5 bg-red-400 rounded-full blur-sm" style={{ animation: 'sparkle-trail 3.1s ease-in-out infinite', animationDelay: '1.2s', boxShadow: '0 0 8px rgba(248,113,113,0.8)' }}></div>
            </>
          )}
          
          {position === 2 && (
            <>
              <div className="absolute bottom-0 left-1/3 w-1.5 h-1.5 bg-gray-300 rounded-full blur-sm" style={{ animation: 'sparkle-trail 3s ease-in-out infinite', animationDelay: '0s' }}></div>
              <div className="absolute bottom-0 right-1/3 w-1 h-1 bg-gray-200 rounded-full blur-sm" style={{ animation: 'sparkle-trail 3.5s ease-in-out infinite', animationDelay: '1s' }}></div>
            </>
          )}
          
          {position === 3 && (
            <>
              <div className="absolute bottom-0 left-1/3 w-1.5 h-1.5 bg-orange-400 rounded-full blur-sm" style={{ animation: 'sparkle-trail 3s ease-in-out infinite', animationDelay: '0s' }}></div>
              <div className="absolute bottom-0 right-1/3 w-1 h-1 bg-orange-300 rounded-full blur-sm" style={{ animation: 'sparkle-trail 3.5s ease-in-out infinite', animationDelay: '1s' }}></div>
            </>
          )}

          {/* Fire glow pulses for position 1 */}
          {position === 1 && (
            <>
              <div className="absolute inset-0 border-4 border-orange-500/50 rounded-t-3xl" style={{ animation: 'pulse-ring 2s ease-out infinite' }}></div>
              <div className="absolute inset-0 border-4 border-yellow-400/40 rounded-t-3xl" style={{ animation: 'pulse-ring 2s ease-out infinite', animationDelay: '0.5s' }}></div>
              <div className="absolute inset-0 border-4 border-red-500/30 rounded-t-3xl" style={{ animation: 'pulse-ring 2s ease-out infinite', animationDelay: '1s' }}></div>
            </>
          )}

          {/* Position Number - Enhanced */}
          <div className={`
            text-3xl md:text-5xl font-black mb-2 md:mb-3 relative z-10
            ${position === 1 ? 'text-yellow-400' : position === 2 ? 'text-gray-300' : 'text-orange-600'}
            drop-shadow-[0_0_15px_currentColor]
          `}
          style={{
            animation: position === 1 ? 'float 2s ease-in-out infinite' : undefined
          }}>
            #{position}
            {position === 1 && (
              <div className="absolute inset-0 blur-2xl bg-yellow-400/40 -z-10"></div>
            )}
          </div>

          {/* Rank Emblem */}
          <div className="mb-2 md:mb-3 relative z-10">
            {getRankEmblem(user)}
          </div>

          {/* User Name - Enhanced */}
          <h3 className={`
            ${position === 1 ? 'text-base md:text-xl' : 'text-sm md:text-lg'} 
            font-black text-center mb-2 px-2
            max-w-full break-words relative z-[100]
            text-white
          `}
          style={{
            textShadow: '0 0 30px rgba(0,0,0,1), 0 6px 12px rgba(0,0,0,1), 3px 3px 6px rgba(0,0,0,0.9)',
            lineHeight: '1.3',
            overflow: 'visible'
          }}>
            {user.is_special && (
              <>
                {/* Particle effects behind text */}
                <span className="absolute inset-0 -z-20 overflow-visible">
                  {/* Particle 1 */}
                  <span className="absolute w-1 h-1 bg-yellow-300 rounded-full left-[20%] bottom-0 blur-[1px]" style={{ 
                    animation: 'float-particle 3s ease-in-out infinite',
                    boxShadow: '0 0 8px 2px rgba(253,224,71,0.9)'
                  }}></span>
                  {/* Particle 2 */}
                  <span className="absolute w-1.5 h-1.5 bg-amber-200 rounded-full left-[40%] bottom-0 blur-[1px]" style={{ 
                    animation: 'float-particle 2.5s ease-in-out infinite 0.5s',
                    boxShadow: '0 0 10px 3px rgba(253,230,138,0.9)'
                  }}></span>
                  {/* Particle 3 */}
                  <span className="absolute w-1 h-1 bg-yellow-400 rounded-full left-[60%] bottom-0 blur-[1px]" style={{ 
                    animation: 'float-particle 3.2s ease-in-out infinite 1s',
                    boxShadow: '0 0 8px 2px rgba(250,204,21,0.9)'
                  }}></span>
                  {/* Particle 4 */}
                  <span className="absolute w-1.5 h-1.5 bg-yellow-200 rounded-full left-[80%] bottom-0 blur-[1px]" style={{ 
                    animation: 'float-particle 2.8s ease-in-out infinite 1.5s',
                    boxShadow: '0 0 10px 3px rgba(254,240,138,0.9)'
                  }}></span>
                  {/* Particle 5 */}
                  <span className="absolute w-1 h-1 bg-amber-300 rounded-full left-[10%] bottom-0 blur-[1px]" style={{ 
                    animation: 'float-particle 3.5s ease-in-out infinite 2s',
                    boxShadow: '0 0 8px 2px rgba(252,211,77,0.9)'
                  }}></span>
                  {/* Particle 6 */}
                  <span className="absolute w-1.5 h-1.5 bg-yellow-300 rounded-full left-[90%] bottom-0 blur-[1px]" style={{ 
                    animation: 'float-particle 2.7s ease-in-out infinite 2.5s',
                    boxShadow: '0 0 10px 3px rgba(253,224,71,0.9)'
                  }}></span>
                </span>
              </>
            )}
            {user.is_special ? (
              user.name.split('').map((letter, index) => (
                <span key={index} className="relative inline-block" style={{ display: 'inline-block' }}>
                  <span className="absolute inset-0 z-10 overflow-hidden pointer-events-none">
                    <span 
                      className="absolute top-0 bottom-0 left-0 right-0"
                      style={{
                        background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.2) 30%, rgba(255,255,255,0.9) 50%, rgba(255,255,255,0.2) 70%, transparent 100%)',
                        animation: `diamond-shine 3s ease-in-out infinite`,
                        animationDelay: `${index * 0.1}s`,
                        transform: 'skewX(-20deg) translateX(-100%)',
                        filter: 'blur(0.5px)'
                      }}
                    ></span>
                  </span>
                  {letter}
                </span>
              ))
            ) : (
              user.name
            )}
          </h3>

          {/* Player Stars */}
          {userStars.get(user.id) && userStars.get(user.id)!.total_stars > 0 && (
            <div className="flex items-center justify-center gap-1 mb-3 md:mb-4 relative z-[100]">
              {/* Particle effects behind stars */}
              <span className="absolute inset-0 -z-20 overflow-visible">
                {/* Particle 1 */}
                <span className="absolute w-1 h-1 bg-yellow-300 rounded-full left-[20%] bottom-0 blur-[1px]" style={{ 
                  animation: 'float-particle 3s ease-in-out infinite',
                  boxShadow: '0 0 8px 2px rgba(253,224,71,0.9)'
                }}></span>
                {/* Particle 2 */}
                <span className="absolute w-1.5 h-1.5 bg-amber-200 rounded-full left-[40%] bottom-0 blur-[1px]" style={{ 
                  animation: 'float-particle 2.5s ease-in-out infinite 0.5s',
                  boxShadow: '0 0 10px 3px rgba(253,230,138,0.9)'
                }}></span>
                {/* Particle 3 */}
                <span className="absolute w-1 h-1 bg-yellow-400 rounded-full left-[60%] bottom-0 blur-[1px]" style={{ 
                  animation: 'float-particle 3.2s ease-in-out infinite 1s',
                  boxShadow: '0 0 8px 2px rgba(250,204,21,0.9)'
                }}></span>
                {/* Particle 4 */}
                <span className="absolute w-1.5 h-1.5 bg-yellow-200 rounded-full left-[80%] bottom-0 blur-[1px]" style={{ 
                  animation: 'float-particle 2.8s ease-in-out infinite 1.5s',
                  boxShadow: '0 0 10px 3px rgba(254,240,138,0.9)'
                }}></span>
                {/* Particle 5 */}
                <span className="absolute w-1 h-1 bg-amber-300 rounded-full left-[10%] bottom-0 blur-[1px]" style={{ 
                  animation: 'float-particle 3.5s ease-in-out infinite 2s',
                  boxShadow: '0 0 8px 2px rgba(252,211,77,0.9)'
                }}></span>
                {/* Particle 6 */}
                <span className="absolute w-1.5 h-1.5 bg-yellow-300 rounded-full left-[90%] bottom-0 blur-[1px]" style={{ 
                  animation: 'float-particle 2.7s ease-in-out infinite 2.5s',
                  boxShadow: '0 0 10px 3px rgba(253,224,71,0.9)'
                }}></span>
              </span>
              {Array.from({ length: Math.min(userStars.get(user.id)!.total_stars, 5) }).map((_, i) => (
                <Star key={i} className="w-4 h-4 md:w-5 md:h-5 text-yellow-400 fill-yellow-400 drop-shadow-[0_0_8px_rgba(250,204,21,0.8)]" />
              ))}
              {userStars.get(user.id)!.total_stars > 5 && (
                <span className="text-xs md:text-sm text-yellow-400 font-bold ml-1 drop-shadow-[0_0_8px_rgba(250,204,21,0.8)]">
                  +{userStars.get(user.id)!.total_stars - 5}
                </span>
              )}
            </div>
          )}

          {/* XP */}
          <div className="w-full mt-auto relative z-[100] pb-2">
            <XPBar xp={user.xp} />
          </div>

          {/* Multi-layer atmospheric glow */}
          <div className="absolute inset-0 rounded-t-3xl bg-gradient-to-t from-black/40 via-transparent to-transparent -z-20 blur-2xl"></div>
          
          {position === 1 && (
            <>
              {/* Fire glow from bottom */}
              <div className="absolute inset-0 rounded-t-3xl bg-gradient-to-t from-orange-600/40 via-yellow-500/25 to-orange-400/20 -z-20 blur-3xl" style={{ animation: 'pulse 2s ease-in-out infinite' }}></div>
              <div className="absolute inset-0 rounded-t-3xl bg-gradient-to-t from-red-600/30 via-orange-500/20 to-yellow-400/15 -z-20 blur-2xl" style={{ animation: 'pulse 2s ease-in-out infinite', animationDelay: '0.5s' }}></div>
              <div className="absolute inset-0 rounded-t-3xl bg-gradient-to-t from-yellow-600/25 via-amber-500/15 to-orange-400/10 -z-20 blur-xl" style={{ animation: 'pulse 2s ease-in-out infinite', animationDelay: '1s' }}></div>
              {/* Fire core from bottom */}
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-48 h-48 bg-orange-500/30 rounded-full blur-3xl -z-20" style={{ animation: 'pulse 1.8s ease-in-out infinite' }}></div>
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-32 h-32 bg-yellow-400/25 rounded-full blur-2xl -z-20" style={{ animation: 'pulse 1.8s ease-in-out infinite', animationDelay: '0.6s' }}></div>
            </>
          )}
          
          {position === 2 && (
            <>
              <div className="absolute inset-0 rounded-t-3xl bg-gradient-to-t from-gray-600/25 via-slate-500/15 to-gray-400/20 -z-20 blur-3xl animate-pulse"></div>
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-40 h-40 bg-gray-300/15 rounded-full blur-2xl -z-20"></div>
            </>
          )}
          
          {position === 3 && (
            <>
              <div className="absolute inset-0 rounded-t-3xl bg-gradient-to-t from-orange-600/25 via-amber-600/15 to-orange-500/20 -z-20 blur-3xl animate-pulse"></div>
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-40 h-40 bg-orange-400/15 rounded-full blur-2xl -z-20"></div>
            </>
          )}
        </div>
      </div>
    );
  };

  const RestCard = ({ user, position }: { user: User; position: number }) => {
    return (
      <div 
        onClick={() => setSelectedUser(user)}
        className="
        relative group
        bg-gradient-to-r from-gray-800/60 via-gray-900/60 to-gray-800/60
        border-2 border-gray-700/40
        rounded-xl p-3 md:p-4
        transition-all duration-300 hover:scale-105 hover:border-cyan-500/50
        backdrop-blur-sm shadow-lg cursor-pointer
      ">
        <div className="flex items-center gap-2 md:gap-4">
          {/* Position */}
          <div className="text-xl md:text-2xl font-black text-gray-400 w-8 md:w-12 text-center shrink-0">
            #{position}
          </div>

          {/* Rank Emblem */}
          {getRankEmblem(user, 'small') && (
            <div className="shrink-0">
              {getRankEmblem(user, 'small')}
            </div>
          )}

          {/* User Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="text-base md:text-lg font-bold truncate relative text-white" style={{ overflow: 'visible' }}>
                {user.is_special && (
                  <>
                    {/* Particle effects behind text */}
                    <span className="absolute inset-0 -z-10 overflow-visible">
                      {/* Particle 1 */}
                      <span className="absolute w-0.5 h-0.5 bg-yellow-300 rounded-full left-[15%] bottom-0 blur-[0.5px]" style={{ 
                        animation: 'float-particle 2.5s ease-in-out infinite',
                        boxShadow: '0 0 6px 1px rgba(253,224,71,0.9)'
                      }}></span>
                      {/* Particle 2 */}
                      <span className="absolute w-1 h-1 bg-amber-200 rounded-full left-[35%] bottom-0 blur-[0.5px]" style={{ 
                        animation: 'float-particle 2.8s ease-in-out infinite 0.5s',
                        boxShadow: '0 0 8px 2px rgba(253,230,138,0.9)'
                      }}></span>
                      {/* Particle 3 */}
                      <span className="absolute w-0.5 h-0.5 bg-yellow-400 rounded-full left-[55%] bottom-0 blur-[0.5px]" style={{ 
                        animation: 'float-particle 3s ease-in-out infinite 1s',
                        boxShadow: '0 0 6px 1px rgba(250,204,21,0.9)'
                      }}></span>
                      {/* Particle 4 */}
                      <span className="absolute w-1 h-1 bg-yellow-200 rounded-full left-[75%] bottom-0 blur-[0.5px]" style={{ 
                        animation: 'float-particle 2.6s ease-in-out infinite 1.5s',
                        boxShadow: '0 0 8px 2px rgba(254,240,138,0.9)'
                      }}></span>
                    </span>
                  </>
                )}
                {user.is_special ? (
                  user.name.split('').map((letter, index) => (
                    <span key={index} className="relative inline-block" style={{ display: 'inline-block' }}>
                      <span className="absolute inset-0 z-10 overflow-hidden pointer-events-none">
                        <span 
                          className="absolute top-0 bottom-0 left-0 right-0"
                          style={{
                            background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.2) 30%, rgba(255,255,255,0.9) 50%, rgba(255,255,255,0.2) 70%, transparent 100%)',
                            animation: `diamond-shine 3s ease-in-out infinite`,
                            animationDelay: `${index * 0.1}s`,
                            transform: 'skewX(-20deg) translateX(-100%)',
                            filter: 'blur(0.5px)'
                          }}
                        ></span>
                      </span>
                      {letter}
                    </span>
                  ))
                ) : (
                  user.name
                )}
              </h3>
              {userStars.get(user.id) && userStars.get(user.id)!.total_stars > 0 && (
                <div className="flex items-center gap-0.5 shrink-0 relative">
                  {/* Particle effects behind stars */}
                  <span className="absolute inset-0 -z-10 overflow-visible">
                    {/* Particle 1 */}
                    <span className="absolute w-0.5 h-0.5 bg-yellow-300 rounded-full left-[15%] bottom-0 blur-[0.5px]" style={{ 
                      animation: 'float-particle 2.5s ease-in-out infinite',
                      boxShadow: '0 0 6px 1px rgba(253,224,71,0.9)'
                    }}></span>
                    {/* Particle 2 */}
                    <span className="absolute w-1 h-1 bg-amber-200 rounded-full left-[35%] bottom-0 blur-[0.5px]" style={{ 
                      animation: 'float-particle 2.8s ease-in-out infinite 0.5s',
                      boxShadow: '0 0 8px 2px rgba(253,230,138,0.9)'
                    }}></span>
                    {/* Particle 3 */}
                    <span className="absolute w-0.5 h-0.5 bg-yellow-400 rounded-full left-[55%] bottom-0 blur-[0.5px]" style={{ 
                      animation: 'float-particle 3s ease-in-out infinite 1s',
                      boxShadow: '0 0 6px 1px rgba(250,204,21,0.9)'
                    }}></span>
                    {/* Particle 4 */}
                    <span className="absolute w-1 h-1 bg-yellow-200 rounded-full left-[75%] bottom-0 blur-[0.5px]" style={{ 
                      animation: 'float-particle 2.6s ease-in-out infinite 1.5s',
                      boxShadow: '0 0 8px 2px rgba(254,240,138,0.9)'
                    }}></span>
                  </span>
                  {Array.from({ length: Math.min(userStars.get(user.id)!.total_stars, 3) }).map((_, i) => (
                    <Star key={i} className="w-3 h-3 md:w-4 md:h-4 text-yellow-400 fill-yellow-400" />
                  ))}
                  {userStars.get(user.id)!.total_stars > 3 && (
                    <span className="text-xs text-yellow-400 font-bold">
                      +{userStars.get(user.id)!.total_stars - 3}
                    </span>
                  )}
                </div>
              )}
            </div>
            <RankBadge rank={user.rank} size="sm" />
          </div>

          {/* XP */}
          <div className="w-32 md:w-48 shrink-0">
            <XPBar xp={user.xp} />
          </div>
        </div>

        {/* Hover glow */}
        <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-cyan-500/0 via-purple-500/0 to-pink-500/0 group-hover:from-cyan-500/10 group-hover:via-purple-500/10 group-hover:to-pink-500/10 transition-all duration-500 -z-10 blur-xl"></div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-950 via-blue-800 to-sky-300 relative overflow-hidden">
      {/* Animated background effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-400 rounded-full mix-blend-multiply filter blur-xl opacity-15 animate-pulse"></div>
        <div className="absolute top-40 right-10 w-72 h-72 bg-cyan-300 rounded-full mix-blend-multiply filter blur-xl opacity-15 animate-pulse animation-delay-2000"></div>
        <div className="absolute -bottom-8 left-20 w-72 h-72 bg-sky-400 rounded-full mix-blend-multiply filter blur-xl opacity-15 animate-pulse animation-delay-4000"></div>
      </div>

      <div className="relative z-10 container mx-auto px-3 md:px-4 py-6 md:py-12">
        {/* Admin Button */}
        <div className="absolute top-4 right-3 md:top-6 md:right-6 z-20">
          <Link
            to="/admin"
            className="flex items-center gap-1 md:gap-2 px-2 md:px-4 py-1.5 md:py-2 bg-gray-800/80 hover:bg-gray-700/80 backdrop-blur-sm border border-gray-600/50 rounded-lg text-gray-300 hover:text-white transition-all duration-200 shadow-lg"
          >
            <Shield className="w-3 h-3 md:w-4 md:h-4" />
            <span className="text-xs md:text-sm font-semibold">Admin</span>
          </Link>
        </div>

        {/* Header */}
        <div className="text-center mb-8 md:mb-12 pt-12 md:pt-0">
          <div className="flex items-center justify-center gap-3 md:gap-4 mb-3 md:mb-4">
            <img 
              src="https://019b19c2-64d0-74af-a20b-44f1a341ddaf.mochausercontent.com/logo.png" 
              alt="CyberLan Logo" 
              className="w-12 h-12 md:w-20 md:h-20 object-contain drop-shadow-[0_0_20px_rgba(139,92,246,0.8)] animate-pulse"
            />
            <h1 className="text-3xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 drop-shadow-2xl">
              CYBERLAN
            </h1>
            <img 
              src="https://019b19c2-64d0-74af-a20b-44f1a341ddaf.mochausercontent.com/logo.png" 
              alt="CyberLan Logo" 
              className="w-12 h-12 md:w-20 md:h-20 object-contain drop-shadow-[0_0_20px_rgba(139,92,246,0.8)] animate-pulse"
            />
          </div>
          <p className="text-sm md:text-xl text-gray-300 font-medium px-4">
            Compite, sube de rango y domina el leaderboard
          </p>
        </div>

        {/* Rangos Disponibles */}
        <div className="max-w-5xl mx-auto mb-12 md:mb-16">
          <h2 className="text-xl md:text-2xl font-black text-center text-gray-200 mb-6 md:mb-8">
            RANGOS DISPONIBLES
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {/* Principiante */}
            <div className="relative group">
              <div className="bg-gradient-to-br from-gray-800/60 via-gray-900/60 to-gray-800/60 border-2 border-blue-500/40 rounded-2xl p-4 md:p-6 transition-all duration-300 hover:scale-105 hover:border-blue-400/70 backdrop-blur-sm shadow-lg">
                <div className="flex flex-col items-center gap-3">
                  <div className="relative w-20 h-20 md:w-24 md:h-24">
                    <div className="absolute inset-0 bg-gradient-to-br from-blue-400/30 via-cyan-400/30 to-blue-600/30 blur-xl animate-pulse"></div>
                    <img 
                      src="https://019b19c2-64d0-74af-a20b-44f1a341ddaf.mochausercontent.com/Principiantes.png" 
                      alt="Principiante" 
                      className="relative z-10 w-20 h-20 md:w-24 md:h-24 object-contain drop-shadow-[0_0_20px_rgba(56,189,248,0.8)]"
                      style={{ filter: 'brightness(1.2)' }}
                    />
                  </div>
                  <RankBadge rank="Principiante" size="sm" />
                  <div className="mt-2 flex items-start gap-2">
                    <Gift className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                    <p className="text-xs md:text-sm text-gray-300 text-center leading-relaxed">
                      {getBenefitForRank("Principiante")}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Gamer */}
            <div className="relative group">
              <div className="bg-gradient-to-br from-gray-800/60 via-gray-900/60 to-gray-800/60 border-2 border-purple-500/40 rounded-2xl p-4 md:p-6 transition-all duration-300 hover:scale-105 hover:border-purple-400/70 backdrop-blur-sm shadow-lg">
                <div className="flex flex-col items-center gap-3">
                  <div className="relative w-20 h-20 md:w-24 md:h-24">
                    <div className="absolute inset-0 bg-gradient-to-br from-purple-400/30 via-fuchsia-400/30 to-purple-600/30 blur-xl animate-pulse"></div>
                    <img 
                      src="https://019b19c2-64d0-74af-a20b-44f1a341ddaf.mochausercontent.com/Gamer.png" 
                      alt="Gamer" 
                      className="relative z-10 w-20 h-20 md:w-24 md:h-24 object-contain drop-shadow-[0_0_20px_rgba(192,38,211,0.8)]"
                      style={{ filter: 'brightness(1.2)' }}
                    />
                  </div>
                  <RankBadge rank="Gamer" size="sm" />
                  <div className="mt-2 flex items-start gap-2">
                    <Gift className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
                    <p className="text-xs md:text-sm text-gray-300 text-center leading-relaxed">
                      {getBenefitForRank("Gamer")}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Pro */}
            <div className="relative group">
              <div className="bg-gradient-to-br from-gray-800/60 via-gray-900/60 to-gray-800/60 border-2 border-red-500/40 rounded-2xl p-4 md:p-6 transition-all duration-300 hover:scale-105 hover:border-red-400/70 backdrop-blur-sm shadow-lg overflow-hidden">
                <div className="flex flex-col items-center gap-3">
                  <div className="relative w-20 h-20 md:w-24 md:h-24">
                    {/* Multi-layered glow auras */}
                    <div className="absolute inset-0 bg-gradient-to-br from-red-500/40 via-rose-500/40 to-red-700/40 blur-xl animate-pulse"></div>
                    <div className="absolute inset-0 bg-gradient-to-br from-red-400/30 via-rose-400/30 to-red-600/30 blur-lg animate-pulse" style={{ animationDelay: '0.5s' }}></div>
                    
                    {/* Orbital rings */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div 
                        className="absolute w-32 h-32 border border-red-400/20 rounded-full"
                        style={{ animation: 'spin 8s linear infinite' }}
                      ></div>
                      <div 
                        className="absolute w-28 h-28 border border-rose-400/15 rounded-full"
                        style={{ animation: 'spin 6s linear infinite reverse' }}
                      ></div>
                    </div>

                    {/* Energy pulses */}
                    <div 
                      className="absolute inset-0 rounded-full bg-gradient-radial from-red-500/30 to-transparent"
                      style={{ animation: 'pulse-ring 2s ease-out infinite' }}
                    ></div>

                    {/* Diagonal light streaks */}
                    <div className="absolute inset-0 overflow-hidden">
                      <div 
                        className="absolute w-0.5 h-20 bg-gradient-to-b from-transparent via-white/60 to-transparent"
                        style={{
                          animation: 'diagonal-streak 4s ease-in-out infinite',
                          left: '20%',
                          top: '-15%',
                          transform: 'rotate(-45deg)'
                        }}
                      ></div>
                    </div>

                    <img 
                      src="https://019b19c2-64d0-74af-a20b-44f1a341ddaf.mochausercontent.com/Veterano.png" 
                      alt="Pro" 
                      className="relative z-10 w-20 h-20 md:w-24 md:h-24 object-contain drop-shadow-[0_0_25px_rgba(239,68,68,1)]"
                      style={{ 
                        filter: 'brightness(1.4) contrast(1.2)',
                        animation: 'float 3s ease-in-out infinite'
                      }}
                    />
                    
                    {/* Enhanced corner shine */}
                    <div 
                      className="absolute top-0 right-0 w-10 h-10 bg-white/80 rounded-full blur-lg"
                      style={{
                        animation: 'corner-shine 3s ease-in-out infinite',
                        opacity: 0
                      }}
                    ></div>
                    
                    {/* Sparkle particles */}
                    <div className="absolute w-1.5 h-1.5 bg-white rounded-full top-2 left-8" style={{ animation: 'sparkle-trail 2s ease-in-out infinite', animationDelay: '0s', boxShadow: '0 0 12px 4px rgba(255,255,255,0.9)' }}></div>
                    <div className="absolute w-2 h-2 bg-red-200 rounded-full top-12 right-4" style={{ animation: 'sparkle-trail 2.5s ease-in-out infinite', animationDelay: '0.3s', boxShadow: '0 0 12px 4px rgba(254,202,202,0.9)' }}></div>
                    <div className="absolute w-1.5 h-1.5 bg-rose-300 rounded-full bottom-6 left-6" style={{ animation: 'sparkle-trail 2.2s ease-in-out infinite', animationDelay: '0.6s', boxShadow: '0 0 12px 4px rgba(253,164,175,0.9)' }}></div>
                    <div className="absolute w-2 h-2 bg-white rounded-full bottom-4 right-8" style={{ animation: 'sparkle-trail 2.8s ease-in-out infinite', animationDelay: '0.9s', boxShadow: '0 0 12px 4px rgba(255,255,255,0.9)' }}></div>
                  </div>
                  <RankBadge rank="Pro" size="sm" />
                  <div className="mt-2 flex items-start gap-2">
                    <Gift className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                    <p className="text-xs md:text-sm text-gray-300 text-center leading-relaxed">
                      {getBenefitForRank("Pro")}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Ciber */}
            <div className="relative group">
              <div className="bg-gradient-to-br from-gray-800/60 via-gray-900/60 to-gray-800/60 border-2 border-yellow-500/50 rounded-2xl p-4 md:p-6 transition-all duration-300 hover:scale-105 hover:border-yellow-400/80 backdrop-blur-sm shadow-lg overflow-hidden">
                <div className="flex flex-col items-center gap-3">
                  <div className="relative w-20 h-20 md:w-24 md:h-24">
                    {/* Multi-layered golden glow auras */}
                    <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/50 via-amber-500/50 to-orange-600/50 blur-xl animate-pulse"></div>
                    <div className="absolute inset-0 bg-gradient-to-br from-yellow-400/40 via-amber-400/40 to-orange-500/40 blur-lg animate-pulse" style={{ animationDelay: '0.5s' }}></div>
                    <div className="absolute inset-0 bg-gradient-to-br from-amber-300/30 via-yellow-400/30 to-orange-400/30 blur-md animate-pulse" style={{ animationDelay: '1s' }}></div>
                    
                    {/* Golden orbital rings */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div 
                        className="absolute w-32 h-32 border border-yellow-400/30 rounded-full"
                        style={{ animation: 'spin 8s linear infinite' }}
                      ></div>
                      <div 
                        className="absolute w-28 h-28 border border-amber-400/20 rounded-full"
                        style={{ animation: 'spin 6s linear infinite reverse' }}
                      ></div>
                      <div 
                        className="absolute w-24 h-24 border border-orange-400/15 rounded-full"
                        style={{ animation: 'spin 10s linear infinite' }}
                      ></div>
                    </div>

                    {/* Golden energy pulses */}
                    <div 
                      className="absolute inset-0 rounded-full bg-gradient-radial from-yellow-400/40 to-transparent"
                      style={{ animation: 'pulse-ring 2s ease-out infinite' }}
                    ></div>
                    <div 
                      className="absolute inset-0 rounded-full bg-gradient-radial from-amber-500/30 to-transparent"
                      style={{ animation: 'pulse-ring 2s ease-out infinite', animationDelay: '1s' }}
                    ></div>

                    {/* Diagonal golden light streaks */}
                    <div className="absolute inset-0 overflow-hidden">
                      <div 
                        className="absolute w-0.5 h-20 bg-gradient-to-b from-transparent via-white/70 to-transparent"
                        style={{
                          animation: 'diagonal-streak 4s ease-in-out infinite',
                          left: '20%',
                          top: '-15%',
                          transform: 'rotate(-45deg)'
                        }}
                      ></div>
                      <div 
                        className="absolute w-0.5 h-16 bg-gradient-to-b from-transparent via-yellow-300/60 to-transparent"
                        style={{
                          animation: 'diagonal-streak 4s ease-in-out infinite',
                          right: '20%',
                          bottom: '-10%',
                          transform: 'rotate(-45deg)',
                          animationDelay: '2s'
                        }}
                      ></div>
                    </div>

                    <img 
                      src="https://019b19c2-64d0-74af-a20b-44f1a341ddaf.mochausercontent.com/Pro.png" 
                      alt="Ciber" 
                      className="relative z-10 w-20 h-20 md:w-24 md:h-24 object-contain drop-shadow-[0_0_35px_rgba(251,191,36,1)]"
                      style={{ 
                        filter: 'brightness(1.5) contrast(1.25)',
                        animation: 'float 3s ease-in-out infinite'
                      }}
                    />
                    
                    {/* Enhanced golden corner shine */}
                    <div 
                      className="absolute top-0 right-0 w-12 h-12 bg-white/90 rounded-full blur-xl"
                      style={{
                        animation: 'corner-shine 3s ease-in-out infinite',
                        opacity: 0
                      }}
                    ></div>
                    
                    {/* Enhanced golden sparkle particles */}
                    <div className="absolute w-2 h-2 bg-white rounded-full top-2 left-8" style={{ animation: 'sparkle-trail 2s ease-in-out infinite', animationDelay: '0s', boxShadow: '0 0 15px 5px rgba(255,255,255,1)' }}></div>
                    <div className="absolute w-2.5 h-2.5 bg-yellow-200 rounded-full top-12 right-4" style={{ animation: 'sparkle-trail 2.5s ease-in-out infinite', animationDelay: '0.3s', boxShadow: '0 0 15px 5px rgba(254,240,138,1)' }}></div>
                    <div className="absolute w-2 h-2 bg-amber-300 rounded-full bottom-6 left-6" style={{ animation: 'sparkle-trail 2.2s ease-in-out infinite', animationDelay: '0.6s', boxShadow: '0 0 15px 5px rgba(252,211,77,1)' }}></div>
                    <div className="absolute w-2.5 h-2.5 bg-white rounded-full bottom-4 right-8" style={{ animation: 'sparkle-trail 2.8s ease-in-out infinite', animationDelay: '0.9s', boxShadow: '0 0 15px 5px rgba(255,255,255,1)' }}></div>
                    <div className="absolute w-1.5 h-1.5 bg-yellow-300 rounded-full top-6 right-12" style={{ animation: 'sparkle-trail 2.3s ease-in-out infinite', animationDelay: '1.2s', boxShadow: '0 0 12px 4px rgba(253,224,71,1)' }}></div>
                    <div className="absolute w-2 h-2 bg-orange-300 rounded-full top-8 left-4" style={{ animation: 'sparkle-trail 2.4s ease-in-out infinite', animationDelay: '1.5s', boxShadow: '0 0 12px 4px rgba(253,186,116,1)' }}></div>
                  </div>
                  <RankBadge rank="Ciber" size="sm" />
                  <div className="mt-2 flex items-start gap-2">
                    <Gift className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
                    <p className="text-xs md:text-sm text-gray-300 text-center leading-relaxed">
                      {getBenefitForRank("Ciber")}
                    </p>
                  </div>
                  <div className="absolute -top-2 -right-2 z-20">
                    <Star className="w-5 h-5 md:w-6 md:h-6 text-yellow-400 fill-yellow-400 animate-pulse drop-shadow-[0_0_10px_rgba(250,204,21,1)]" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        {loading ? (
          <div className="flex justify-center items-center py-20">
            <Zap className="w-12 h-12 text-cyan-400 animate-pulse" />
          </div>
        ) : users.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-2xl text-gray-400">No hay jugadores todavía</p>
            <p className="text-gray-500 mt-2">¡Sé el primero en unirte!</p>
          </div>
        ) : (
          <>
            {/* Top 3 Podium */}
            {top3.length > 0 && (
              <div className="max-w-6xl mx-auto mb-16 md:mb-32">
                <div className="flex flex-col md:flex-row items-stretch md:items-end justify-center gap-4 md:gap-8 pb-8">
                  {top3.map((user, index) => (
                    <PodiumCard key={user.id} user={user} position={index + 1} />
                  ))}
                </div>
              </div>
            )}

            {/* Rest of players */}
            {rest.length > 0 && (
              <div className="max-w-4xl mx-auto">
                <h2 className="text-xl md:text-2xl font-black text-gray-300 mb-4 md:mb-6 text-center">
                  Otros Jugadores
                </h2>
                <div className="space-y-3 md:space-y-6">
                  {rest.map((user, index) => (
                    <RestCard key={user.id} user={user} position={index + 4} />
                  ))}
                </div>
              </div>
            )}
          </>
        )}

        {/* Footer */}
        <div className="text-center mt-16 text-gray-500 text-sm">
          <p>Administrado por el equipo del ciber</p>
        </div>
      </div>

      {/* Player Modal */}
      {selectedUser && (
        <PlayerModal 
          user={selectedUser} 
          onClose={() => setSelectedUser(null)} 
        />
      )}
    </div>
  );
}
