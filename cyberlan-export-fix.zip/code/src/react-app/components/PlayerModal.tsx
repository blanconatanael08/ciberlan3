import { useEffect, useState } from "react";
import { User } from "@/shared/types";
import { X, Star, Award, Trophy, Sparkles } from "lucide-react";
import RankBadge from "./RankBadge";

interface PlayerStar {
  id: number;
  user_id: number;
  season: string;
  stars: number;
  created_at: string;
  updated_at: string;
}

interface PlayerModalProps {
  user: User;
  onClose: () => void;
}

export default function PlayerModal({ user, onClose }: PlayerModalProps) {
  const [playerStars, setPlayerStars] = useState<PlayerStar[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPlayerStars();
  }, [user.id]);

  const loadPlayerStars = async () => {
    try {
      const response = await fetch(`/api/player-stars/user/${user.id}`);
      const data = await response.json();
      setPlayerStars(data);
    } catch (error) {
      console.error("Error loading player stars:", error);
    } finally {
      setLoading(false);
    }
  };

  const totalStars = playerStars.reduce((sum, s) => sum + s.stars, 0);

  return (
    <div 
      className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 rounded-2xl shadow-2xl border-2 border-purple-500/30 animate-in zoom-in-95 duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onClose();
          }}
          className="absolute top-4 right-4 z-10 p-2 bg-gray-800/80 hover:bg-gray-700 rounded-full transition-colors backdrop-blur-sm"
        >
          <X className="w-6 h-6 text-white" />
        </button>

        {/* Header with Rank Badge - Epic Style */}
        <div className="relative overflow-hidden bg-gradient-to-br from-purple-900/50 via-blue-900/50 to-cyan-900/50 p-8 border-b-2 border-purple-500/30">
          {/* Animated Background Effects */}
          <div className="absolute inset-0 opacity-30">
            <div className="absolute top-0 left-1/4 w-64 h-64 bg-purple-500/30 rounded-full blur-3xl animate-pulse"></div>
            <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-cyan-500/30 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
          </div>

          {/* Content */}
          <div className="relative z-10 text-center">
            {/* Trophy Icon */}
            <div className="flex justify-center mb-4">
              <div className="relative">
                <Trophy className="w-16 h-16 text-yellow-400 drop-shadow-[0_0_20px_rgba(250,204,21,0.8)]" />
                <div className="absolute inset-0 animate-ping opacity-20">
                  <Trophy className="w-16 h-16 text-yellow-400" />
                </div>
              </div>
            </div>

            {/* Player Name */}
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4 drop-shadow-[0_0_30px_rgba(0,0,0,1)]" style={{
              textShadow: '0 0 40px rgba(168,85,247,0.8), 0 0 20px rgba(139,92,246,0.6), 0 4px 8px rgba(0,0,0,1)'
            }}>
              {user.name}
            </h2>

            {/* Rank Badge - Large */}
            <div className="flex justify-center mb-4">
              <div className="transform scale-125">
                <RankBadge rank={user.rank} size="lg" />
              </div>
            </div>

            {/* Total Stars */}
            <div className="flex items-center justify-center gap-2 bg-gray-900/50 backdrop-blur-sm rounded-full px-6 py-3 border border-yellow-500/30 w-fit mx-auto">
              <Sparkles className="w-5 h-5 text-yellow-400" />
              <span className="text-yellow-400 font-bold text-lg">
                {totalStars} {totalStars === 1 ? 'Estrella' : 'Estrellas'} Totales
              </span>
              <Sparkles className="w-5 h-5 text-yellow-400" />
            </div>

            {/* XP Display */}
            <div className="mt-4 text-cyan-300 font-semibold text-lg">
              <Award className="w-5 h-5 inline-block mr-2" />
              {user.xp.toLocaleString()} XP
            </div>
          </div>
        </div>

        {/* Stars by Season */}
        <div className="p-6 md:p-8">
          {loading ? (
            <div className="text-center py-12 text-gray-400">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500 mx-auto mb-4"></div>
              Cargando estrellas...
            </div>
          ) : playerStars.length === 0 ? (
            <div className="text-center py-12">
              <Star className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400 text-lg">Este jugador aún no tiene estrellas asignadas</p>
            </div>
          ) : (
            <div className="space-y-4">
              <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
                <Star className="w-7 h-7 text-yellow-400 fill-yellow-400" />
                Historial de Estrellas
              </h3>
              <p className="text-gray-400 text-sm mb-6">
                Cada temporada representa un logro o evento especial. Las estrellas se suman para tu puntaje total.
              </p>
              
              {playerStars.map((starData, index) => (
                <div 
                  key={starData.id}
                  className="relative group bg-gradient-to-r from-gray-800/50 to-gray-800/30 border-2 border-yellow-500/20 rounded-xl p-5 hover:border-yellow-500/40 transition-all duration-300 hover:shadow-[0_0_30px_rgba(250,204,21,0.3)] overflow-hidden animate-in slide-in-from-bottom duration-300"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  {/* Background Glow Effect */}
                  <div className="absolute inset-0 bg-gradient-to-r from-yellow-500/0 via-yellow-500/5 to-yellow-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  
                  <div className="relative z-10 flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="flex items-center justify-center w-8 h-8 bg-yellow-500/20 rounded-full border border-yellow-500/40">
                          <span className="text-yellow-400 font-bold text-sm">#{playerStars.length - index}</span>
                        </div>
                        <h4 className="text-xl font-bold text-white flex items-center gap-2">
                          <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
                          {starData.season}
                        </h4>
                      </div>
                      <div className="flex items-center gap-1 flex-wrap">
                        {Array.from({ length: Math.min(starData.stars, 10) }).map((_, i) => (
                          <Star 
                            key={i} 
                            className="w-6 h-6 md:w-7 md:h-7 text-yellow-400 fill-yellow-400 drop-shadow-[0_0_8px_rgba(250,204,21,0.8)] animate-in zoom-in duration-200"
                            style={{ animationDelay: `${i * 50}ms` }}
                          />
                        ))}
                        {starData.stars > 10 && (
                          <span className="text-xl md:text-2xl text-yellow-400 font-black ml-2 drop-shadow-[0_0_12px_rgba(250,204,21,0.8)]">
                            +{starData.stars - 10}
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <div className="text-right ml-4">
                      <div className="bg-gradient-to-br from-yellow-500/20 to-amber-600/20 border-2 border-yellow-500/40 rounded-xl px-4 py-2 min-w-[80px]">
                        <div className="text-3xl font-black text-yellow-400 drop-shadow-[0_0_12px_rgba(250,204,21,0.8)]">
                          {starData.stars}
                        </div>
                        <div className="text-xs text-yellow-300 font-semibold uppercase">
                          {starData.stars === 1 ? 'Estrella' : 'Estrellas'}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
