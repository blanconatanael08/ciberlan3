import { Rank } from "@/shared/types";
import { Crown, Sword, Target, Zap } from "lucide-react";

interface RankBadgeProps {
  rank: Rank;
  size?: "sm" | "md" | "lg";
}

const rankConfig = {
  Principiante: {
    color: "from-gray-500 to-gray-600",
    borderColor: "border-gray-400",
    textColor: "text-gray-300",
    glowColor: "shadow-gray-500/50",
    icon: Target,
  },
  Gamer: {
    color: "from-green-500 to-emerald-600",
    borderColor: "border-green-400",
    textColor: "text-green-300",
    glowColor: "shadow-green-500/50",
    icon: Zap,
  },
  Pro: {
    color: "from-purple-500 to-pink-600",
    borderColor: "border-purple-400",
    textColor: "text-purple-300",
    glowColor: "shadow-purple-500/50",
    icon: Sword,
  },
  Ciber: {
    color: "from-yellow-400 to-orange-500",
    borderColor: "border-yellow-300",
    textColor: "text-yellow-200",
    glowColor: "shadow-yellow-500/70",
    icon: Crown,
  },
};

export default function RankBadge({ rank, size = "md" }: RankBadgeProps) {
  const config = rankConfig[rank];
  const Icon = config.icon;

  const sizeClasses = {
    sm: "px-3 py-1 text-xs gap-1.5",
    md: "px-4 py-2 text-sm gap-2",
    lg: "px-6 py-3 text-base gap-2.5",
  };

  const iconSizes = {
    sm: "w-3 h-3",
    md: "w-4 h-4",
    lg: "w-5 h-5",
  };

  return (
    <div
      className={`
        inline-flex items-center ${sizeClasses[size]}
        bg-gradient-to-r ${config.color}
        border-2 ${config.borderColor}
        rounded-full font-bold uppercase tracking-wider
        ${config.textColor}
        shadow-lg ${config.glowColor}
        transform transition-transform hover:scale-105
      `}
    >
      <Icon className={iconSizes[size]} />
      {rank}
    </div>
  );
}
