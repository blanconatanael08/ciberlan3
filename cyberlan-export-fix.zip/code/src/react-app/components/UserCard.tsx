import { User } from "@/shared/types";
import RankBadge from "./RankBadge";
import XPBar from "./XPBar";

interface UserCardProps {
  user: User;
  position: number;
}

export default function UserCard({ user, position }: UserCardProps) {
  const getPositionStyle = (pos: number) => {
    if (pos === 1) return "from-yellow-900/30 via-gray-800/40 to-gray-900/30 border-yellow-500/50 shadow-yellow-500/20";
    if (pos === 2) return "from-gray-700/30 via-gray-800/40 to-gray-900/30 border-gray-400/50 shadow-gray-400/20";
    if (pos === 3) return "from-orange-900/30 via-gray-800/40 to-gray-900/30 border-orange-600/50 shadow-orange-600/20";
    return "from-gray-800/40 via-gray-900/40 to-gray-800/40 border-gray-700/30 shadow-gray-700/10";
  };

  return (
    <div
      className={`
        relative group
        bg-gradient-to-r ${getPositionStyle(position)}
        border-2 rounded-2xl
        p-6 transition-all duration-300
        hover:scale-[1.02] hover:shadow-2xl
        backdrop-blur-sm
      `}
    >
      <div className="flex items-center gap-6">
        {/* Rank Emblem for Principiante */}
        {user.rank === "Principiante" && (
          <div className="relative flex items-center justify-center w-40 h-40 shrink-0">
            {/* Glow effect background */}
            <div className="absolute inset-0 bg-gradient-to-br from-blue-400/40 via-cyan-400/40 to-blue-600/40 rounded-full blur-xl animate-pulse"></div>
            <div className="absolute inset-0 bg-gradient-to-br from-blue-300/30 via-cyan-300/30 to-blue-500/30 rounded-full blur-lg animate-pulse" style={{ animationDelay: '0.5s' }}></div>
            
            {/* Main emblem image */}
            <img 
              src="https://019b19c2-64d0-74af-a20b-44f1a341ddaf.mochausercontent.com/Principiantes.png" 
              alt="Principiante" 
              className="relative z-10 w-36 h-36 object-contain drop-shadow-[0_0_20px_rgba(56,189,248,0.9)] animate-pulse"
              style={{ filter: 'brightness(1.2) contrast(1.1)' }}
            />
            
            {/* Rotating ring effect */}
            <div className="absolute inset-0 border-2 border-cyan-400/50 rounded-full animate-spin" style={{ animationDuration: '8s' }}></div>
            <div className="absolute inset-2 border-2 border-blue-400/30 rounded-full animate-spin" style={{ animationDuration: '6s', animationDirection: 'reverse' }}></div>
          </div>
        )}

        {/* User Info */}
        <div className="flex-1 min-w-0">
          <h3 className="text-2xl font-black text-white mb-2 truncate">
            {user.name}
          </h3>
          <div className="flex items-center gap-4">
            <RankBadge rank={user.rank} size="md" />
          </div>
        </div>

        {/* XP */}
        <div className="w-64 shrink-0">
          <XPBar xp={user.xp} />
        </div>
      </div>

      {/* Animated border glow */}
      <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-cyan-500/0 via-purple-500/0 to-pink-500/0 group-hover:from-cyan-500/20 group-hover:via-purple-500/20 group-hover:to-pink-500/20 transition-all duration-500 -z-10 blur-xl"></div>
    </div>
  );
}
