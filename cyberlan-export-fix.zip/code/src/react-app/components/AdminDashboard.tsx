import { useState, useEffect } from "react";
import { User, Rank, RankBenefit, PlayerStar } from "@/shared/types";
import { Plus, Edit, Trash2, Search, Gift, Eye, Star } from "lucide-react";
import RankBadge from "./RankBadge";

interface VisitStats {
  total: number;
  today: number;
  week: number;
  month: number;
}

interface PlayerStarWithName extends PlayerStar {
  user_name: string;
}

interface AdminDashboardProps {
  adminPassword: string;
}

interface UserFormData {
  name: string;
  rank: Rank;
  xp: number;
  is_special: boolean;
}

export default function AdminDashboard({ adminPassword }: AdminDashboardProps) {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [formData, setFormData] = useState<UserFormData>({
    name: "",
    rank: "Principiante",
    xp: 0,
    is_special: false,
  });
  
  const [rankBenefits, setRankBenefits] = useState<RankBenefit[]>([]);
  const [editingBenefit, setEditingBenefit] = useState<Rank | null>(null);
  const [benefitText, setBenefitText] = useState("");
  const [visitStats, setVisitStats] = useState<VisitStats>({
    total: 0,
    today: 0,
    week: 0,
    month: 0
  });
  
  const [playerStars, setPlayerStars] = useState<PlayerStarWithName[]>([]);
  const [showCreateStarForm, setShowCreateStarForm] = useState(false);
  const [starFormData, setStarFormData] = useState({
    user_id: 0,
    season: "",
    stars: 0,
  });

  useEffect(() => {
    loadUsers();
    loadRankBenefits();
    loadVisitStats();
    loadPlayerStars();
  }, []);

  const loadUsers = async () => {
    try {
      const response = await fetch("/api/users");
      const data = await response.json();
      setUsers(data);
    } catch (error) {
      console.error("Error loading users:", error);
    } finally {
      setLoading(false);
    }
  };

  const loadRankBenefits = async () => {
    try {
      const response = await fetch("/api/rank-benefits");
      const data = await response.json();
      setRankBenefits(data);
    } catch (error) {
      console.error("Error loading rank benefits:", error);
    }
  };

  const loadVisitStats = async () => {
    try {
      const response = await fetch("/api/visits/stats", {
        headers: {
          "X-Admin-Password": adminPassword,
        },
      });
      const data = await response.json();
      setVisitStats(data);
    } catch (error) {
      console.error("Error loading visit stats:", error);
    }
  };

  const loadPlayerStars = async () => {
    try {
      const response = await fetch("/api/player-stars", {
        headers: {
          "X-Admin-Password": adminPassword,
        },
      });
      const data = await response.json();
      setPlayerStars(data);
    } catch (error) {
      console.error("Error loading player stars:", error);
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch("/api/users", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Admin-Password": adminPassword,
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        await loadUsers();
        setShowCreateForm(false);
        setFormData({ name: "", rank: "Principiante", xp: 0, is_special: false });
      }
    } catch (error) {
      console.error("Error creating user:", error);
    }
  };

  const handleUpdate = async (userId: number) => {
    try {
      const response = await fetch(`/api/users/${userId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "X-Admin-Password": adminPassword,
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        await loadUsers();
        setEditingUser(null);
        setFormData({ name: "", rank: "Principiante", xp: 0, is_special: false });
      }
    } catch (error) {
      console.error("Error updating user:", error);
    }
  };

  const handleDelete = async (userId: number) => {
    if (!confirm("¿Estás seguro de eliminar este usuario?")) return;

    try {
      const response = await fetch(`/api/users/${userId}`, {
        method: "DELETE",
        headers: {
          "X-Admin-Password": adminPassword,
        },
      });

      if (response.ok) {
        await loadUsers();
      }
    } catch (error) {
      console.error("Error deleting user:", error);
    }
  };

  const startEdit = (user: User) => {
    setEditingUser(user);
    setFormData({
      name: user.name,
      rank: user.rank,
      xp: user.xp,
      is_special: user.is_special,
    });
    setShowCreateForm(false);
  };

  const cancelEdit = () => {
    setEditingUser(null);
    setShowCreateForm(false);
    setFormData({ name: "", rank: "Principiante", xp: 0, is_special: false });
  };

  const startEditBenefit = (benefit: RankBenefit) => {
    setEditingBenefit(benefit.rank);
    setBenefitText(benefit.benefit || "");
  };

  const handleUpdateBenefit = async (rank: Rank) => {
    try {
      const response = await fetch(`/api/rank-benefits/${rank}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "X-Admin-Password": adminPassword,
        },
        body: JSON.stringify({ benefit: benefitText }),
      });

      if (response.ok) {
        await loadRankBenefits();
        setEditingBenefit(null);
        setBenefitText("");
      }
    } catch (error) {
      console.error("Error updating benefit:", error);
    }
  };

  const cancelEditBenefit = () => {
    setEditingBenefit(null);
    setBenefitText("");
  };

  const handleCreateStar = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch("/api/player-stars", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Admin-Password": adminPassword,
        },
        body: JSON.stringify(starFormData),
      });

      if (response.ok) {
        await loadPlayerStars();
        setShowCreateStarForm(false);
        setStarFormData({ user_id: 0, season: "", stars: 0 });
      }
    } catch (error) {
      console.error("Error creating player star:", error);
    }
  };

  const handleDeleteStar = async (starId: number) => {
    if (!confirm("¿Estás seguro de eliminar esta asignación de estrellas?")) return;

    try {
      const response = await fetch(`/api/player-stars/${starId}`, {
        method: "DELETE",
        headers: {
          "X-Admin-Password": adminPassword,
        },
      });

      if (response.ok) {
        await loadPlayerStars();
      }
    } catch (error) {
      console.error("Error deleting player star:", error);
    }
  };



  const ranks: Rank[] = ["Principiante", "Gamer", "Pro", "Ciber"];

  const filteredUsers = users.filter((user) =>
    user.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Visit Statistics - Compact */}
      <div className="bg-gray-800/50 border border-blue-500/30 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Eye className="w-5 h-5 text-blue-400" />
            <h3 className="text-sm font-bold text-white">Visitas</h3>
          </div>
          <div className="flex gap-4 text-sm">
            <span className="text-gray-400">Total: <span className="text-white font-bold">{visitStats.total.toLocaleString()}</span></span>
            <span className="text-gray-400">Hoy: <span className="text-white font-bold">{visitStats.today.toLocaleString()}</span></span>
          </div>
        </div>
      </div>

      {/* Player Stars Section - Simplified */}
      <div className="bg-gray-800/50 border border-yellow-500/30 rounded-lg p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-yellow-400" />
            <h3 className="text-sm font-bold text-white">Asignar Estrellas</h3>
          </div>
          <button
            onClick={() => {
              setShowCreateStarForm(!showCreateStarForm);
              setStarFormData({ user_id: 0, season: "", stars: 0 });
            }}
            className="flex items-center gap-1 px-3 py-1.5 bg-yellow-600 hover:bg-yellow-700 text-white rounded text-sm font-semibold transition-colors"
          >
            <Plus className="w-4 h-4" />
            {showCreateStarForm ? 'Cancelar' : 'Nueva'}
          </button>
        </div>

        {showCreateStarForm && (
          <form onSubmit={handleCreateStar} className="grid grid-cols-1 md:grid-cols-4 gap-3 mb-4">
            <select
              value={starFormData.user_id}
              onChange={(e) => setStarFormData({ ...starFormData, user_id: parseInt(e.target.value) })}
              className="px-3 py-2 bg-gray-900 border border-gray-600 rounded text-white text-sm focus:outline-none focus:border-yellow-500"
              required
            >
              <option value={0}>Jugador...</option>
              {users.map((user) => (
                <option key={user.id} value={user.id}>{user.name}</option>
              ))}
            </select>

            <input
              type="text"
              value={starFormData.season}
              onChange={(e) => setStarFormData({ ...starFormData, season: e.target.value })}
              className="px-3 py-2 bg-gray-900 border border-gray-600 rounded text-white text-sm focus:outline-none focus:border-yellow-500"
              placeholder="Nombre temporada..."
              required
            />

            <input
              type="number"
              value={starFormData.stars}
              onChange={(e) => setStarFormData({ ...starFormData, stars: parseInt(e.target.value) || 0 })}
              className="px-3 py-2 bg-gray-900 border border-gray-600 rounded text-white text-sm focus:outline-none focus:border-yellow-500"
              placeholder="Estrellas..."
              min="0"
              required
            />

            <button
              type="submit"
              className="px-3 py-2 bg-yellow-600 hover:bg-yellow-700 text-white rounded text-sm font-semibold transition-colors"
            >
              Guardar
            </button>
          </form>
        )}

        {playerStars.length > 0 && (
          <div className="mt-4 space-y-2 max-h-60 overflow-y-auto">
            <p className="text-xs text-gray-400 mb-2">Estrellas asignadas ({playerStars.length}):</p>
            {playerStars.map((star) => (
              <div key={star.id} className="flex items-center justify-between bg-gray-900/50 border border-gray-700 rounded p-2">
                <div className="flex-1 min-w-0">
                  <div className="text-white text-sm font-semibold truncate">{star.user_name}</div>
                  <div className="text-xs text-gray-400 truncate">{star.season}</div>
                </div>
                <div className="flex items-center gap-2 ml-2">
                  <div className="flex items-center gap-1">
                    {Array.from({ length: Math.min(star.stars, 3) }).map((_, i) => (
                      <Star key={i} className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                    ))}
                    {star.stars > 3 && (
                      <span className="text-xs text-yellow-400 font-bold">+{star.stars - 3}</span>
                    )}
                  </div>
                  <button
                    onClick={() => handleDeleteStar(star.id)}
                    className="p-1.5 bg-red-600 hover:bg-red-700 text-white rounded transition-colors"
                    title="Eliminar"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {playerStars.length === 0 && (
          <p className="text-xs text-gray-400 mt-2">No hay estrellas asignadas todavía.</p>
        )}
      </div>

      {/* Rank Benefits Section - Simplified */}
      <div className="bg-gray-800/50 border border-purple-500/30 rounded-lg p-4">
        <div className="flex items-center gap-2 mb-4">
          <Gift className="w-5 h-5 text-purple-400" />
          <h3 className="text-sm font-bold text-white">Beneficios por Rango</h3>
        </div>
        <div className="space-y-3">
          {rankBenefits.map((benefit) => (
            <div key={benefit.rank} className="bg-gray-900/50 border border-gray-700 rounded p-3">
              {editingBenefit === benefit.rank ? (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <RankBadge rank={benefit.rank} size="sm" />
                  </div>
                  <textarea
                    value={benefitText}
                    onChange={(e) => setBenefitText(e.target.value)}
                    className="w-full px-2 py-1.5 bg-gray-800 border border-gray-600 rounded text-white text-sm focus:outline-none focus:border-purple-500 resize-none"
                    rows={2}
                    placeholder="Beneficios..."
                  />
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleUpdateBenefit(benefit.rank)}
                      className="px-2 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded text-xs font-semibold transition-colors"
                    >
                      Guardar
                    </button>
                    <button
                      onClick={cancelEditBenefit}
                      className="px-2 py-1 bg-gray-600 hover:bg-gray-700 text-white rounded text-xs font-semibold transition-colors"
                    >
                      Cancelar
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-between gap-2">
                  <RankBadge rank={benefit.rank} size="sm" />
                  <button
                    onClick={() => startEditBenefit(benefit)}
                    className="p-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded transition-colors"
                  >
                    <Edit className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Users Section - Simplified */}
      <div className="bg-gray-800/50 border border-green-500/30 rounded-lg p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-white">Usuarios ({users.length})</h3>
          </div>
          <button
            onClick={() => {
              setShowCreateForm(!showCreateForm);
              setEditingUser(null);
              setFormData({ name: "", rank: "Principiante", xp: 0, is_special: false });
            }}
            className="flex items-center gap-1 px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white rounded text-sm font-semibold transition-colors"
          >
            <Plus className="w-4 h-4" />
            {showCreateForm ? 'Cancelar' : 'Nuevo'}
          </button>
        </div>

        {showCreateForm && (
          <form onSubmit={handleCreate} className="grid grid-cols-1 md:grid-cols-5 gap-3 mb-4">
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="px-3 py-2 bg-gray-900 border border-gray-600 rounded text-white text-sm focus:outline-none focus:border-green-500"
              placeholder="Nombre..."
              required
            />

            <select
              value={formData.rank}
              onChange={(e) => setFormData({ ...formData, rank: e.target.value as Rank })}
              className="px-3 py-2 bg-gray-900 border border-gray-600 rounded text-white text-sm focus:outline-none focus:border-green-500"
            >
              {ranks.map((rank) => (
                <option key={rank} value={rank}>{rank}</option>
              ))}
            </select>

            <input
              type="number"
              value={formData.xp}
              onChange={(e) => setFormData({ ...formData, xp: parseInt(e.target.value) || 0 })}
              className="px-3 py-2 bg-gray-900 border border-gray-600 rounded text-white text-sm focus:outline-none focus:border-green-500"
              placeholder="XP..."
              min="0"
              required
            />

            <label className="flex items-center gap-2 px-3 py-2 bg-gray-900 border border-gray-600 rounded cursor-pointer hover:border-yellow-500">
              <input
                type="checkbox"
                checked={formData.is_special}
                onChange={(e) => setFormData({ ...formData, is_special: e.target.checked })}
                className="w-4 h-4 text-yellow-600 bg-gray-700 border-gray-600 rounded focus:ring-yellow-500"
              />
              <span className="text-yellow-400 text-sm font-semibold">⭐ Especial</span>
            </label>

            <button
              type="submit"
              className="px-3 py-2 bg-green-600 hover:bg-green-700 text-white rounded text-sm font-semibold transition-colors"
            >
              Crear
            </button>
          </form>
        )}

        {!showCreateForm && (
          <div className="relative mb-3">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Buscar..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-3 py-2 bg-gray-900 border border-gray-600 rounded text-white text-sm placeholder-gray-500 focus:outline-none focus:border-cyan-500"
            />
          </div>
        )}

        <div className="space-y-2 max-h-96 overflow-y-auto">
          {filteredUsers.map((user) => (
            <div key={user.id} className="bg-gray-900/50 border border-gray-700 rounded p-2">
              {editingUser?.id === user.id ? (
                <div className="grid grid-cols-5 gap-2">
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="px-2 py-1 bg-gray-800 border border-gray-600 rounded text-white text-sm focus:outline-none focus:border-blue-500"
                  />
                  <select
                    value={formData.rank}
                    onChange={(e) => setFormData({ ...formData, rank: e.target.value as Rank })}
                    className="px-2 py-1 bg-gray-800 border border-gray-600 rounded text-white text-sm focus:outline-none focus:border-blue-500"
                  >
                    {ranks.map((rank) => (
                      <option key={rank} value={rank}>{rank}</option>
                    ))}
                  </select>
                  <input
                    type="number"
                    value={formData.xp}
                    onChange={(e) => setFormData({ ...formData, xp: parseInt(e.target.value) || 0 })}
                    className="px-2 py-1 bg-gray-800 border border-gray-600 rounded text-white text-sm focus:outline-none focus:border-blue-500"
                    min="0"
                  />
                  <label className="flex items-center justify-center gap-1 px-2 py-1 bg-gray-800 border border-gray-600 rounded cursor-pointer hover:border-yellow-500">
                    <input
                      type="checkbox"
                      checked={formData.is_special}
                      onChange={(e) => setFormData({ ...formData, is_special: e.target.checked })}
                      className="w-3 h-3"
                    />
                    <span className="text-yellow-400 text-xs">⭐</span>
                  </label>
                  <div className="flex gap-1">
                    <button
                      onClick={() => handleUpdate(user.id)}
                      className="flex-1 p-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs transition-colors"
                    >
                      Guardar
                    </button>
                    <button
                      onClick={cancelEdit}
                      className="flex-1 p-1 bg-gray-600 hover:bg-gray-700 text-white rounded text-xs transition-colors"
                    >
                      Cancelar
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1">
                      <div className="text-white font-semibold text-sm truncate">{user.name}</div>
                      {user.is_special && <span className="text-yellow-400">⭐</span>}
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <RankBadge rank={user.rank} size="sm" />
                      <span className="text-xs text-gray-400">{user.xp.toLocaleString()} XP</span>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <button
                      onClick={() => startEdit(user)}
                      className="p-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors"
                      title="Editar"
                    >
                      <Edit className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => handleDelete(user.id)}
                      className="p-1.5 bg-red-600 hover:bg-red-700 text-white rounded transition-colors"
                      title="Eliminar"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {users.length === 0 && !loading && (
          <p className="text-center py-8 text-gray-400 text-sm">No hay usuarios todavía.</p>
        )}

        {filteredUsers.length === 0 && users.length > 0 && (
          <p className="text-center py-8 text-gray-400 text-sm">No se encontraron usuarios.</p>
        )}
      </div>
    </div>
  );
}
