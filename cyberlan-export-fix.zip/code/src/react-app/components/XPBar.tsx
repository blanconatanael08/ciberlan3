interface XPBarProps {
  xp: number;
  maxXp?: number;
}

export default function XPBar({ xp, maxXp = 10000 }: XPBarProps) {
  const percentage = Math.min((xp / maxXp) * 100, 100);

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-semibold text-cyan-400">XP</span>
        <span className="text-sm font-bold text-white">{xp.toLocaleString()}</span>
      </div>
      <div className="h-3 bg-gray-800/50 rounded-full overflow-hidden border border-gray-700">
        <div
          className="h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500 transition-all duration-500 ease-out relative overflow-hidden"
          style={{ width: `${percentage}%` }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer"></div>
        </div>
      </div>
    </div>
  );
}
