import z from "zod";

export const RankEnum = z.enum(["Principiante", "Gamer", "Pro", "Ciber"]);
export type Rank = z.infer<typeof RankEnum>;

export const UserSchema = z.object({
  id: z.number(),
  name: z.string(),
  rank: RankEnum,
  xp: z.number(),
  is_special: z.boolean(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type User = z.infer<typeof UserSchema>;

export const CreateUserSchema = z.object({
  name: z.string().min(1, "El nombre es requerido"),
  rank: RankEnum,
  xp: z.number().min(0, "XP debe ser mayor o igual a 0"),
  is_special: z.boolean().optional(),
});

export type CreateUser = z.infer<typeof CreateUserSchema>;

export const UpdateUserSchema = z.object({
  name: z.string().min(1).optional(),
  rank: RankEnum.optional(),
  xp: z.number().min(0).optional(),
  is_special: z.boolean().optional(),
});

export type UpdateUser = z.infer<typeof UpdateUserSchema>;

export const AdminPasswordSchema = z.object({
  password: z.string(),
});

export const RankBenefitSchema = z.object({
  id: z.number(),
  rank: RankEnum,
  benefit: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type RankBenefit = z.infer<typeof RankBenefitSchema>;

export const UpdateRankBenefitSchema = z.object({
  benefit: z.string(),
});

export type UpdateRankBenefit = z.infer<typeof UpdateRankBenefitSchema>;

export const PlayerStarSchema = z.object({
  id: z.number(),
  user_id: z.number(),
  season: z.string(),
  stars: z.number(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type PlayerStar = z.infer<typeof PlayerStarSchema>;

export const CreatePlayerStarSchema = z.object({
  user_id: z.number(),
  season: z.string().min(1, "La temporada es requerida"),
  stars: z.number().min(0, "Las estrellas deben ser mayor o igual a 0"),
});

export type CreatePlayerStar = z.infer<typeof CreatePlayerStarSchema>;

export const UpdatePlayerStarSchema = z.object({
  season: z.string().min(1).optional(),
  stars: z.number().min(0).optional(),
});

export type UpdatePlayerStar = z.infer<typeof UpdatePlayerStarSchema>;
